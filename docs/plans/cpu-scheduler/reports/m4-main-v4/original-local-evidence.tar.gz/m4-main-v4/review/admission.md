# Independent v4 prelaunch admission review

Approved for the single locally admitted m4-main-v4 native attempt, subject to
final pre-run manifest readback and the frozen wrapper's formal verification.
No material admission blocker was found. This receipt does not establish native
qualification, overall M4 acceptance, or publication authority.

The reviewed source is clean at 9ce4ca8aca004cf51782c59e91dd9fd7af5beed5,
tree 05c47e8ca113fcd400d9c21bf9b6eb121555f1bc. Independently read and hashed
all 968 recorded source files and compared each with its committed Git blob;
all match. The source contract hash and all 14 committed fixture hashes match.
All 21 frozen nonbinary inputs and all 637 preservation hashes match, including
all 40 stopped-v3 files, its failure marker, the old failed v2 evidence, prior
schema review, and wrapper-repair history. No preserved evidence was modified.

The actual isolated release executable is 86,511,784 bytes, mode 0500, SHA256
6335eedf7a5cf1c955d819325180f6d48cce288d55fefd31a458fc559ef12932.
It matches the already completed build binary and frozen build log. The
historical build terminal result is exit 0 with no native invocation; no build
was relaunched by this review. Existing optional inference warnings remain
preserved in release-build.log.

The wrapper and supervisor exactly match the independently approved repair.
Canonical SHA256 of their sorted compact JSON hash pair is
cd085b2564c9634ff01e3d4b8c725951e9c2ee3163b228abc0435c9051a726db.
The receipt fields required by one_shot.verify_inputs were inspected directly.
The wrapper verifies the final manifest, exact source/tree/clean worktree,
source and fixture bytes, actual binary, scope/accounting/environment and all
prior evidence, then requires this hash-bound independent admission. It
persists an exclusive fsynced claim before any native spawn. Existing output,
claims or formal preflight failure refuse execution. There is no retry or
claim-reset path in the admitted procedure.

The actual CPU affinity, cgroup limits and inherited controls match the
frozen environment. Runtime offline controls, isolated registry destination,
fixture-override removal and one CPU thread per private gateway agree with the
native source and accounting witness. Scope remains untrained committed BERT8/12,
hello world, retained A,A,B,B,A, five fresh singleton comparisons in that order,
and one BERT8 pressure refusal. Main guard/resident RAM is 48/32 MiB, main
RAM/VRAM capacity 1104/1024 MiB, pressure RAM 80 MiB. Authoritative per-kind task
maxima remain 536895107/536908694 bytes. There are no new cancellation cases,
trained models, production/default activation, GPU or performance claims.

The exact launch-plan command invokes the explicit Python path and frozen
one_shot.py execute with wrapper.log redirection from the source worktree.
The parent must capture the ACTUAL terminal exec_command/write_stdin result
into outer-exit.json after return. Missing, nonzero, pending or disconnected
outer outcomes cannot be inferred from execution-status.json and never permit
a relaunch. The launch plan preserves that rule explicitly.

The integrated pure outer validator independently requires terminal tool exit
integer zero with no running session identifier; exact launch request/argv,
source/tree/binary and reviewed runtime identity; completed inner/child zero;
no wrapper errors; reaped and complete supervision; no retained owner, error or
signal; and consistent positive PID/PGID identities. Every known failure marker
(preflight-failure.json, qualification-stopped.json, finalization-failure.json,
execution-status.next.json) vetoes qualification even beside a completed-zero
status. The saved-data reviewer invokes this gate before the native oracle.
Outer observation remains trusted tool evidence captured by the parent, not
cryptographic attestation that JSON alone can establish.

The native verify_owner AST is identical to the separately reviewed schema
preflight copy. Against that copy, the schema changes only the outer protocol;
the saved-data reviewer changes only that protocol plus the outer-veto import
and integration. Existing full native identity/generation, real receipts,
charges, task ACK joins, phase intervals, artifact bytes/goldens, raw event to
byte-copied SQLite joins, exact pressure Failed terminal, session closes,
teardown and bounded collector checks are retained. The required totals remain
8 loads, 2 retains, 10 forward/drains, 8 stops, 8 native instances and 11 runs.
OS signals cannot provide native ACKs or resource-release authority.

Independently reran all 15 model-free unittest methods (6 outer and 9 schema)
through imported test suites using the exact planned launcher interpreter:
15 passed, zero failures/errors. Test main blocks were not executed, so their
existing results/logs were not rewritten. The actual old v2 pressure JSON still
fails its required terminal check. No original SQLite store was opened.

Toolchain provenance clarification: toolchain-freeze.json is byte-identical to
the stopped-v3 historical build metadata, including Python 3.12.3/Clang 17 and
the native_v3_invocations_before_build field. The exact planned wrapper
interpreter currently reports Python 3.12.14/Clang 22; its executable SHA256 is
fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7.
These are distinct recorded facts, not a claim of version equality. The launch
path is explicit, the current schema tests passed on it, and the contract does
not require equality to the historical Python patch version. No frozen input
was edited to hide this provenance distinction.

Applicable standards were read from the local Coding-Standards checkout at
188beda1fa477d21d576c233dd8c7f4c4c267d23: Core, Router, Verification,
Concurrency, Contracts, Resilience and Launcher guidance. This is bounded
prelaunch evidence review; synthetic schema success supplies no native
qualification. Non-daemon supervision retains unresolved work, and bounded
caller observation does not promise unconditional kernel reap or control of
descendants that escape the owned process group.

Only this report and independent-admission.json are written by this reviewer.
No Cargo, native/model process, download, environment change, cleanup,
publication, push or merge was performed. A first read-only audit command had a
local variable-shadowing print error after hashing; its corrected read-only
command completed with zero mismatches. No formal preflight or invocation was
attempted. Final manifest construction/readback and formal verify remain the
parent's next gates; any actual rejected gate permanently stops this attempt.
