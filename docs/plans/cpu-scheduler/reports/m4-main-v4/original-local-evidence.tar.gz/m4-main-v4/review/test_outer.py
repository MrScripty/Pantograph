"""Synthetic outer-schema fixtures only; no subprocess, facade or model."""
import copy
import hashlib
import json
from pathlib import Path
import unittest
from outer_checks import validate_outer, FAILURES, RUNTIME, PROTOCOL


class OuterTests(unittest.TestCase):
    def setUp(self):
        self.runtime = {
            'one_shot.py':'70d657b78b3ef48cfb7c541454376dec3f8c535e3af9866cb29d8302e24dc29b',
            'owned_process.py':'3e7b95f9b12fee0ee9dc8a02805172d08a20b599bac669fe576ba21fc1d3251b'}
        self.plan={'tool_request':{'cmd':'SYNTHETIC-NOT-EXECUTED','workdir':'/SYNTHETIC'},'argv':['SYNTHETIC']}
        self.status={'source_head':'SYNTHETIC','source_tree':'SYNTHETIC','binary_sha256':'a'*64,
            'state':'completed','exit_code':0,'child_exit_code':0,'wrapper_errors':[], 'pid':101,'pgid':101,
            'process_supervision':{'process_reaped':True,'cleanup_complete':True,'supervisor_retained':False,
                'supervisor_non_daemon':True,'child_exit_code':0,'error_count':0,'errors':[],'signals':[],
                'pid':101,'pgid':101}}
        self.outer={'capture_kind':'exec_tool_terminal_result','state':'completed','protocol':PROTOCOL,
            'tool_result':{'exit_code':0},'launch_request':self.plan['tool_request'],
            'launch_argv':self.plan['argv'],'source_head':'SYNTHETIC','source_tree':'SYNTHETIC',
            'binary_sha256':'a'*64,'runtime_identity_sha256':RUNTIME}

    def check_outer(self, outer=None, status=None, artifacts=(), runtime=None):
        return validate_outer(outer or self.outer,status or self.status,artifacts,self.plan,runtime or self.runtime)

    def test_synthetic_positive_shape_only(self):
        self.assertEqual(self.check_outer()['outer_wrapper_exit'],0)

    def test_every_failure_artifact_vetoes_even_completed_zero(self):
        for name in FAILURES:
            with self.subTest(name=name), self.assertRaisesRegex(AssertionError,'failure artifact'):
                self.check_outer(artifacts=[name])

    def test_outer_nonzero_missing_or_pending_vetoes_completed_zero(self):
        for tool in ({'exit_code':1},{},{'exit_code':False},{'exit_code':0,'session_id':123}):
            outer=copy.deepcopy(self.outer);outer['tool_result']=tool
            with self.subTest(tool=tool), self.assertRaisesRegex(AssertionError,'outer wrapper exit'):
                self.check_outer(outer=outer)

    def test_wrapper_error_or_failed_state_vetoes_child_zero(self):
        for key,value in [('wrapper_errors',['injected post-write exception']),('state','wrapper_failed'),('child_exit_code',1)]:
            status=copy.deepcopy(self.status);status[key]=value
            with self.subTest(key=key), self.assertRaisesRegex(AssertionError,'wrapper observation'):
                self.check_outer(status=status)

    def test_supervisor_faults_and_forced_stop_veto_success(self):
        for key,value in [('cleanup_complete',False),('process_reaped',False),('supervisor_retained',True),
                          ('supervisor_non_daemon',False),('child_exit_code',1),('error_count',1),
                          ('errors',['injected']),('signals',[15])]:
            status=copy.deepcopy(self.status);status['process_supervision'][key]=value
            with self.subTest(key=key), self.assertRaisesRegex(AssertionError,'supervision vetoes'):
                self.check_outer(status=status)

    def test_wrong_pid_launch_source_or_runtime_vetoes(self):
        status=copy.deepcopy(self.status);status['pgid']=102
        with self.assertRaisesRegex(AssertionError,'process/group'):self.check_outer(status=status)
        for key,value in [('launch_argv',['wrong']),('source_head','wrong'),('binary_sha256','wrong'),('runtime_identity_sha256','wrong')]:
            outer=copy.deepcopy(self.outer);outer[key]=value
            with self.subTest(key=key), self.assertRaises(AssertionError):self.check_outer(outer=outer)


if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(OuterTests))
    Path(__file__).with_name('outer-test-result.json').write_text(json.dumps({'kind':'SYNTHETIC OUTER SCHEMA ONLY',
        'tests':result.testsRun,'passed':result.wasSuccessful(),'failures':len(result.failures),
        'errors':len(result.errors),'native_invocations':0,'native_qualified':False},indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
