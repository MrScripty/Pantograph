"""Pure outer-exit/failure-artifact veto. Never executes a process or model."""
import hashlib
import json

PROTOCOL = 'm4-serial-residency-v4-supervised'
RUNTIME = 'cd085b2564c9634ff01e3d4b8c725951e9c2ee3163b228abc0435c9051a726db'
FAILURES = {'preflight-failure.json', 'qualification-stopped.json',
            'finalization-failure.json', 'execution-status.next.json'}


def require(value, message):
    if not value:
        raise AssertionError(message)


def validate_outer(outer, status, artifacts, plan, runtime_hashes):
    require(not (FAILURES & set(artifacts)), 'failure artifact vetoes qualification')
    require(outer.get('capture_kind') == 'exec_tool_terminal_result'
            and outer.get('state') == 'completed' and outer.get('protocol') == PROTOCOL,
            'completed external tool observation is required')
    tool = outer.get('tool_result', {})
    require(type(tool.get('exit_code')) is int and tool['exit_code'] == 0
            and 'session_id' not in tool, 'outer wrapper exit is not confirmed zero')
    require(outer.get('launch_request') == plan['tool_request']
            and outer.get('launch_argv') == plan['argv'], 'outer launch scope mismatch')
    require(outer.get('source_head') == status['source_head']
            and outer.get('source_tree') == status['source_tree']
            and outer.get('binary_sha256') == status['binary_sha256'],
            'outer source/binary identity mismatch')
    identity = hashlib.sha256(json.dumps(runtime_hashes, sort_keys=True,
                separators=(',', ':')).encode()).hexdigest()
    require(identity == RUNTIME == outer.get('runtime_identity_sha256'),
            'reviewed runtime identity mismatch')
    require(status.get('state') == 'completed' and status.get('exit_code') == 0
            and status.get('child_exit_code') == 0 and status.get('wrapper_errors') == [],
            'wrapper observation error vetoes qualification')
    owner = status.get('process_supervision') or {}
    require(owner.get('process_reaped') is True and owner.get('cleanup_complete') is True
            and owner.get('supervisor_retained') is False
            and owner.get('supervisor_non_daemon') is True
            and type(owner.get('child_exit_code')) is int and owner['child_exit_code'] == 0
            and type(owner.get('error_count')) is int and owner['error_count'] == 0
            and owner.get('errors') == [] and owner.get('signals') == [],
            'incomplete/forced/error supervision vetoes qualification')
    require(type(status.get('pid')) is int and status['pid'] > 0
            and status['pid'] == status.get('pgid') == owner.get('pid') == owner.get('pgid'),
            'owned child process/group identity mismatch')
    return {'outer_wrapper_exit': 0, 'child_exit': 0, 'no_failure_artifacts': True,
            'process_reaped': True, 'forced_process_signals': [],
            'native_cleanup_proof': 'only the separate unchanged native evidence oracle can establish ACKs'}
