"""Model-free checks for a proposed future envelope; not an execution launcher.

No model, network, process, database, or filesystem operations occur here.
Synthetic positive fixtures prove validator behavior, never native qualification.
"""
import re
from datetime import datetime, timedelta

PROTOCOL = 'm4-serial-residency-v4-supervised'
PRODUCER_PROTOCOL = 'm4-serial-residency-v2-readback'
HEAD = '9ce4ca8aca004cf51782c59e91dd9fd7af5beed5'
TREE = '05c47e8ca113fcd400d9c21bf9b6eb121555f1bc'


def require(value, message):
    if not value:
        raise AssertionError(message)


def validate_status(statuses, binary_freeze, argv):
    """Validate one future completed status against its independently frozen binary.

    This does not establish that a process ran or that there were no hidden
    invocations. A separately reviewed one-shot wrapper and raw evidence must
    establish those facts before native acceptance.
    """
    require(len(statuses) == 1, 'exactly one execution status is required')
    s = statuses[0]
    require(s.get('protocol') == PROTOCOL, 'wrong cohort protocol')
    require(s.get('producer_protocol') == PRODUCER_PROTOCOL,
            'legacy producer label must be explicit')
    require(s.get('source_head') == HEAD and s.get('source_tree') == TREE,
            'wrong composed source or tree')
    require(s.get('state') == 'completed' and type(s.get('exit_code')) is int
            and s['exit_code'] == 0, 'execution is not completed successfully')
    require(type(s.get('attempt')) is int and s['attempt'] == 1,
            'one integer attempt=1 is required')
    require(not any(k.startswith('attempt') and k != 'attempt' for k in s),
            'ambiguous legacy attempt field')
    require(s.get('retry_allowed') is False, 'retry permission must be false')
    require(s.get('argv') == argv, 'execution scope differs from frozen argv')
    require(binary_freeze.get('source_head') == HEAD
            and binary_freeze.get('source_tree') == TREE
            and binary_freeze.get('protocol') == PROTOCOL
            and binary_freeze.get('producer_protocol') == PRODUCER_PROTOCOL,
            'binary freeze belongs to another source/protocol')
    expected = binary_freeze.get('binary_sha256')
    require(isinstance(expected, str) and re.fullmatch('[0-9a-f]{64}', expected),
            'actual frozen binary SHA256 is required')
    require(s.get('binary_sha256') == expected, 'wrong binary SHA256')
    times = []
    for name in ('started_utc', 'completed_utc'):
        require(isinstance(s.get(name), str) and s[name], 'missing ' + name)
        try:
            stamp = datetime.fromisoformat(s[name])
        except ValueError as error:
            raise AssertionError('invalid UTC timestamp: ' + name) from error
        require(stamp.utcoffset() == timedelta(0), 'timestamp must be UTC: ' + name)
        times.append(stamp)
    require(times[0] <= times[1], 'completion must follow start')
    return s


def validate_pressure_terminal(events, run, public_error):
    """Require an actual matching failed run terminal; effects alone cannot pass.

    Input event authenticity is established separately by the copied reviewer's
    unchanged byte-copy SQLite/export comparison, not by this JSON shape check.
    """
    relevant = [e for e in events if e.get('workflow_run_id') == run]
    snapshots = [e for e in relevant
                 if e.get('payload', {}).get('payload_type') == 'run_snapshot_accepted']
    terminals = [e for e in relevant
                 if e.get('payload', {}).get('payload_type') == 'run_terminal']
    require(len(snapshots) == 1, 'one matching admitted run snapshot is required')
    require(len(terminals) == 1, 'one matching raw pressure terminal is required')
    terminal = terminals[0]
    payload = terminal['payload']
    require(terminal.get('node_id') is None and payload.get('status') == 'failed',
            'pressure must have a workflow Failed terminal')
    error = payload.get('error')
    require(isinstance(error, str) and error.strip()
            and isinstance(public_error, str) and error in public_error,
            'terminal must preserve the actual public failure cause')
    require(type(snapshots[0].get('event_seq')) is int
            and type(terminal.get('event_seq')) is int
            and snapshots[0]['event_seq'] < terminal['event_seq'],
            'pressure terminal must follow admission')
    require(not any(e.get('payload', {}).get('payload_type')
                    == 'scheduler_task_attempt_lifecycle_changed' for e in relevant),
            'pressure must not create a Started or Completed attempt')
    return terminal
