# Local M4 v4 main-cohort qualification

The single authorized synthetic-fixture main cohort completed with actual outer
tool exit 0 on 2026-10-20. The frozen saved-data oracle passes, and independent raw
evidence review approved the bounded main result with no material blockers.
The signed-off review is recorded separately in this directory; this report does
not substitute for that review or accept overall M4.

- Source: `9ce4ca8aca004cf51782c59e91dd9fd7af5beed5`; tree
  `05c47e8ca113fcd400d9c21bf9b6eb121555f1bc`; clean worktree.
- Release binary SHA256:
  `6335eedf7a5cf1c955d819325180f6d48cce288d55fefd31a458fc559ef12932`.
- Reviewed wrapper/supervisor identity:
  `cd085b2564c9634ff01e3d4b8c725951e9c2ee3163b228abc0435c9051a726db`.
- Independent final readback approved the 24-input pre-run manifest SHA256
  `28b9d391f6593d1e942fd64ea193c389a383fad17b68f7949ff4167e805d90d8`.
- Formal verification ran once and passed before the only native invocation.
  Exact tool returns are in `parent-execution-record.json`; the independently
  checked outer return is `/workspace/m4-main-v4/outer-exit.json`.
- Attempt 1, zero retries. Wrapper and child exited 0; owned process reaped,
  cleanup complete, no wrapper/supervisor errors or containment signals.

Each public request used exactly `hello world`, one CPU thread and the original
committed, untrained BERT8/12 fixtures. Retained A,A,B,B,A produced 3 loads,
2 retains, 5 forward/drains and 3 stops. Five fresh comparison owners produced
5 loads, 5 forward/drains and 5 stops, with each teardown preceding the next
owner. All 10 embedding artifacts match the fixed goldens, maximum absolute
error `5.960464477539063e-08`, under unchanged tolerances.

The one pressure request refused before native load/forward or reservation
mutation. Raw event 5 is exactly one Failed run terminal carrying the original
additive residency-headroom error. No attempt Started/Completed is present;
session close/shutdown and final empty registry checks pass. Total: 11 public
requests, 8 distinct native instances, 8 loads, 2 retains, 10 forward/drains,
8 stops and 61 bounded collector rows.

The saved-data oracle retains the genuine receipt/instance/profile/settings/
generation joins, per-task ACK and full additive charge checks, old-stop ACK
before new load, real phase intervals, raw event/projection/artifact agreement
and final teardown checks. OS process containment supplies none of these native
ACKs. Original SQLite evidence was reviewed through temporary byte copies.
SHA256 body bytes and recorded BLAKE3 joins are checked; the standard-library
review script does not independently recompute artifact BLAKE3.

The 360 post-execution input files and all 637 historical preservation entries
remain unchanged. The original failed v1/v2 attempts and stopped v3 are retained
with their original failures. No download, publication, push, merge, cleanup,
environment change or new cancellation execution occurred.

This establishes only the bounded local main-cohort result. The older cancellation
supplement has a distinct source and disclosed observation limits; its combination
with this source requires parent review. Overall M4-C4/C5 acceptance, integration,
focused publication and exact published-head required CI remain separate gates.
No trained-model, production/default-policy, GPU, native-batching, semantic-quality,
allocator/RSS budget, speedup or general performance claim follows.
