# Independent completed MAIN native evidence review

Approved for the bounded local MAIN protocol evidence at source
9ce4ca8aca004cf51782c59e91dd9fd7af5beed5, tree
05c47e8ca113fcd400d9c21bf9b6eb121555f1bc. No material blocker was found in
that evidence. This does not accept full M4-C4 or overall M4. The older
96691fd7 cancellation supplement remains separately scoped; the parent must
combine the relevant source, tests and supplement before deciding the complete
C4 gate. C5 exact-published-head CI remains unavailable for local 9ce source.
No publication, push or merge is authorized by this review.

The previously frozen executable remains mode 0500 and SHA256
6335eedf7a5cf1c955d819325180f6d48cce288d55fefd31a458fc559ef12932.
The wrapper/supervisor identity remains
cd085b2564c9634ff01e3d4b8c725951e9c2ee3163b228abc0435c9051a726db.
All 968 source files match both current clean worktree bytes and their committed
Git blobs. All 24 pre-run hashes, all 360 post-execution nonbinary hashes and
all 637 historical preservation hashes match. The post-execution manifest
covers the exact nonbinary population, excluding itself; it includes all 329
MAIN evidence files. The existing saved review's MAIN preservation map exactly
matches that subset. These hashes were checked again after independent review.

## Execution and outer failure gate

The parent's captured actual terminal exec-tool result records exit 0 in
3.163085205 seconds, with no running session identifier. It matches the exact
frozen launch command, argv, source/tree/binary and runtime pair. This trusted
tool capture is distinct from the inner completed file; serialized JSON does
not independently attest an unseen launch. The parent reports one formal
verification at exit 0 followed by one execution; this reviewer launched neither.

The persisted invocation claim binds the same attempt=1, retry_allowed=false,
start instant, source/tree, binary, argv and wrapper identity as execution-status.
The recorded execution ran 2026-10-20T07:03:59.892753Z to
2026-10-20T07:04:02.854337Z. Child and wrapper exit are 0. PID/PGID 67082 match
the retained supervisor record; the direct child is reaped, cleanup complete,
the owner is not retained, and errors/signals are empty. None of the known
preflight, qualification-stopped, finalization or pending-status failure
artifacts exists. The frozen outer veto was independently reapplied and passed.
Process containment supplies no native ACK or resource-release authority.

## Native deciding evidence

| Owner scope | Loads | Retains | Forward/drains | Stops |
| --- | ---: | ---: | ---: | ---: |
| Retained A,A,B,B,A | 3 | 2 | 5 | 3 |
| Five singleton comparisons together | 5 | 0 | 5 | 5 |
| Pressure refusal | 0 | 0 | 0 | 0 |
| Total | 8 | 2 | 10 | 8 |

The unchanged, source-inspected native owner oracle was reapplied directly to
each of the seven owner directories without rerunning its CLI or any native
process. Every owner summary exactly matches the saved report. The source
oracle retains full run/node/task/attempt/request/candidate/lease identity,
native loaded-instance/profile/settings identity, and actual +2 drain generation
checks. Warm calls retain the same private native owner and guard incarnation;
cold switches/reload and singleton comparisons produce eight distinct actual
native loaded instances. Eleven distinct public runs are present.

Per-kind task charges match the frozen source-derived maxima 536895107 and
536908694 bytes. Actual drain records retain the 48 MiB guard, 32 MiB resident
charge and full task RAM/VRAM claims. The exact registry task ACK removes only
the matching task lease; guard/resident state persists until the genuine
switch or final stop ACK. Switch/final records consume the exact preceding
native owner, clear all charges only after ACK, and finish with empty registries.
Each acknowledged owner teardown precedes the next owner's first raw event.
All 16 execution/graph session closes succeed.

All seven exported event streams agree with SQLite queries on temporary byte
copies of the original database bytes. No original store was opened by SQLite.
There are 125 raw events. The collector contains exactly the expected 61 ordered
rows, no overflow, and stays within the 128-row, 8-KiB-per-line and 1-MiB limits.
Actual required phase intervals are present; missing intervals are errors.
Raw runtime Started/Completed events join the exact attempt and Completed task
lease. Separate vectors-node work remains non-runtime work.

Ten public vectors equal their stored artifact bodies and retained readback,
have correct dimensions, and satisfy the unchanged independent fixture golden
tolerances. Maximum absolute error is 5.960464477539063e-08. Original fixture
copies, input hashes, raw artifact identifiers/hash/size joins, projection
boundaries/cursors and Completed projection states pass the preserved oracle.
Stored BLAKE3 joins agree; this standard-library review does not recompute
BLAKE3 bodies and does not claim otherwise.

The pressure run has five raw events: an accepted snapshot and one matching
workflow-level Failed terminal at sequence 5, with the actual refusal cause
preserved in the public error. Its native records are preparation plan plus
matching headroom refusal, with no authorization to Start. Required RAM
620781187 exceeds the frozen 80 MiB capacity. There are no runtime attempts,
loads, forwards, retains, stops, claims or native owner, and session closes and
shutdown succeed. This directly resolves the MAIN protocol's earlier missing
pressure terminal/close evidence without relabeling or retrying the failed v2.

## Review integrity and limits

The initial independent reader assertion accidentally included the separate
vectors-node lifecycle events while checking infer Started/Completed. Raw
inspection showed that infer has exactly its own runtime pair and vectors has
legitimate non-runtime events. The reader query was corrected to node_id=infer;
every runtime attempt and lease then matched. No frozen evidence, acceptance
oracle or source was edited, and no native process was rerun. This was a reader
scope error, not a rejected formal/native gate.

The independently reapplied saved-data checks and separate hash/claim/session/
lifecycle checks all passed. The source remained clean and original/post-run/
historical bytes remained unchanged. Only this report and the accompanying
independent-native-review.json are durable outputs from this completed-evidence
review; temporary SQLite copies were outside the frozen root. No Cargo, model,
reference generator, download, environment change, publication or merge occurred.

These observations apply to committed untrained BERT8/12, hello world, one CPU
thread per private gateway and the admitted fixed protocol. They establish no
trained-model quality, general production readiness, GPU, RSS/allocator budget,
fairness equivalence, interrupted compute, or speedup. Per-phase scalar timings
are actual observations, while separate buffering and wall-clock granularity
limit cross-component timing conclusions. The full C4 cancellation/combined
evidence decision and C5 published-head CI remain with the parent.

## Exact evidence bindings

- Post-execution manifest: 012789483953415b9918489dc192c9e1560e766ccfc98a6632aac76106a86a02
- Pre-run manifest: 28b9d391f6593d1e942fd64ea193c389a383fad17b68f7949ff4167e805d90d8
- Existing saved report: 0682c2b558c009f1c13d3c2c8bf352836b467b975d4ea680597b4f440fe33adb
- Outer terminal capture: 55cd39bf7285e8ec6c6aa77e896c18eac2babb5a4190ce43578e198bdfa2652c
- Execution status: cbd88428078da8e5ab4eff7d314a9fd2592994bf78316dc02dd259e1638ca535
- Invocation claim: 8d06ce4e773842b13ee1f6fffccb05a415727d72b6e8a4b47e926998b798cddf
- Frozen saved reviewer: dd7e04fd06a713fa053e91f6c6e26928368785ed1cb0ef852fb3cb784bde4bad
- Frozen outer validator: 9c40122c1570a1533d9cb28f8c15c809f77f35c6e9a083bde39256add0f7f517
- Frozen schema: b9d034043780281d8be412b17cf4d83e61ac0a61226f2d2783bfa06671238ed6

Signed off by independent reviewer /root/m4_v4_admission_review for the bounded
MAIN evidence scope above. The companion JSON binds this report's exact bytes;
its digest is returned separately to the parent.

