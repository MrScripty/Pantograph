# Independent model-free schema preflight review

**Approved for the bounded model-free preflight. No material blocker found at
this stage.** This is neither native qualification nor an execution admission.
The composed binary freeze and one-shot execution wrapper are not prepared or
reviewed. M4 C4 remains Partial/Blocked; original v1/v2 failures are unchanged.

Reviewed source identity: clean `9ce4ca8aca004cf51782c59e91dd9fd7af5beed5`, tree
`05c47e8ca113fcd400d9c21bf9b6eb121555f1bc`. Independently checked all 968 recorded
source hashes, all 29 preserved composition archive members, all 351 original v2
post-execution file hashes and the original 14 fixture bytes. The fixture admission
is byte-identical to the old fixture-freeze manifest. No production source,
original evidence, database or model was modified or executed by this reviewer.

## Schema and copied-reviewer findings

`validate_status` requires exactly one completed successful envelope, exact
composed source/tree, explicit new cohort protocol and legacy producer label,
integer `attempt=1` (rejecting booleans and other attempt-prefixed aliases),
`retry_allowed=false`, exact argv and matching independently frozen binary hash.
It validates UTC timestamps and nondecreasing completion time. The schema does
not pretend these values prove a process ran or prevent hidden invocations; the
future one-shot wrapper and independently verified physical evidence must do so.

`validate_pressure_terminal` adds a guard to the preserved pressure checks: one
matching admitted snapshot, one workflow-level Failed terminal after admission,
nonblank terminal failure contained in the public error, and no attempt lifecycle
event for that run. It cannot authenticate synthetic JSON. The copied reviewer's
unchanged temporary-byte-copy SQLite/export comparison remains the actual event
authenticity check; its other refusal, zero-effects, close and shutdown criteria
also remain required. Zero effects or an expected public error alone still fail.

Independently reproduced the exact recorded diff against old reviewer SHA256
`747465e0debd5b358e3031bc4960b48c83d3c8ea08f805e9b742d76e3bd73a1f`.
Only `verify_freeze`, `verify_owner`, `review` and `main` have changed function
ASTs. Removing the single added pressure guard makes `verify_owner` identical
to the old AST. Artifact/golden verification, full native identity and warm +2
lineage, task-only ACK removal, guard/resident/task claims, counts/order, eight
distinct native instances, ten successful outputs, eleven runs including pressure,
61 expected log rows and 128/8-KiB/1-MiB bounds are preserved.

Replacing the old literal binary hash with a future binary-freeze hash is
appropriate for a rebuilt composed binary. It is not a frozen binary claim now.
The copied reviewer still hashes the actual file and checks source/protocol/
features/build scope. Both the schema and reviewer must be hash-bound with all
other external dependencies in the eventual pre-run freeze. Explicit CLI paths
avoid silently targeting the consumed v2 root.

## Test evidence and boundary

Current `preflight.log` and `preflight-result.json` record **nine unittest methods
passed**, zero failures/errors, with multiple negative subcases. The earlier
statement of ten methods was corrected; the result is nine. Initial passing log
and result are retained separately after timestamp/alias tightening.

The tests label every positive envelope and pressure event fixture SYNTHETIC.
The status fixture's repeated `a` hash and year-2000 timestamps are validator
inputs, not a binary or execution observation. The real saved v2 pressure events
are read from JSON and still reject because their required Failed terminal is
absent. No original SQLite database is opened. Importing the copied reviewer
defines its functions; it does not call its full saved-data review, spawn a
process, construct a facade, refresh projections or execute a model. This reviewer
inspected source and existing logs; it did not rerun the preflight.

## Remaining gates and authority

No full future-cohort fixture tree, actual composed release binary or one-shot
launcher has been frozen/tested here. Their exact interface, exclusive fresh-root
creation, single invocation, status lifecycle, failure/teardown handling and
absence of retries require review before any execution. Preserve the full fixed
AABBA/comparison/pressure protocol and all existing physical, output, terminal,
close and cleanup requirements. Resolve the legacy producer label explicitly.
Do not infer qualification from these synthetic positives or from schema success.

The copied `verify_prior_evidence` retains v1/supplement preservation checks;
original v2 preservation was checked separately in recovery and this review.
Keep that v2 preservation gate in future freeze/evidence work. Some unchanged
diagnostic/report text in the copied reviewer still says “v2”; its new envelope
protocol/source identity must govern attribution. A label-only cleanup before
freeze is reasonable but is not a model-free preflight blocker.

The current parent's instruction authorizes recovery and model-free reviewer/
schema work only and explicitly holds native execution and publication. This
review respects that scope. It does not infer an unseen standing rule requiring
fresh user approval for every cohort; the next admission decision belongs to the
parent under the existing trusted task history. This review grants no permission
to execute, publish, merge or replace the environment.

## Reviewed bytes

| File | SHA256 |
| --- | --- |
| prospective_schema.py | `d44f881f269f2735251bbda05a07a2b3b58df22f9c590a45c4be32af9a8741a7` |
| review_saved_composed.py | `f4a4e14c344b78e3b699e3929e6152b77d8682d8f3116900c4093544f3a681d2` |
| test_preflight.py | `d34c6e8d501b9e4709c92f818fda4475b0f6a17f76e656ab8166831c2640524d` |
| reviewer-copy.diff | `f51e4abbd381d0a3880320b64aacd27e87b918ded0afc0ba397bad276c4560b4` |
| reviewer-provenance.json | `8efde6dc73c25a4181c130fda0e1a8cdf46da824725a3c850dc1fb45f10bde96` |
| fixture-admission.json | `578e11d41c9784ef3a8f6711d7bc4c8cf4bda47bb9d7bfa61c4b2232b72f1817` |
| preflight.log | `a96a4fc5a38151066f6bee98bbd5a74158c04af7997999f9fa11c193f34d1b0e` |
| preflight-result.json | `83260c938ab004831a80b6eafccdf1ecd6a50cc8f35434c4cea25e86a03b86e8` |
