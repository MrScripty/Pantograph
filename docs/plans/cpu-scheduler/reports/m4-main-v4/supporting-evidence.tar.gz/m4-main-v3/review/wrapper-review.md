# Independent wrapper review: NOT_ADMITTED

**Verdict: NOT_ADMITTED. This qualification attempt is stopped before any native
invocation.** The parent acknowledged the material finding below and explicitly
directed stop/report, no repair or rerun. This review does not grant execution
authority. No `independent-admission.json` has been created.

Reviewed wrapper `/workspace/m4-main-v3/one_shot.py`, SHA256
`c22d5b3d3c22394ba77424c18d1d73deb767f0babdc1a7fd270e837e33a03af0`.
Reviewed mocked tests `/workspace/m4-main-v3/test_one_shot.py`, SHA256
`8ac55c4825ec1c66e0e230a50062f241d5faa828ad18baffacf1092509c298dd`.
The composed production worktree remains clean at
`9ce4ca8aca004cf51782c59e91dd9fd7af5beed5`, tree
`05c47e8ca113fcd400d9c21bf9b6eb121555f1bc`.

## Material finding: live-child ownership is lost on wrapper failure

`run_once`, lines 168–172, creates a child with `subprocess.Popen`, then writes
the running status and waits. If `write_status` at line 171 raises after that
successful spawn, or `child.wait()` at line 172 raises/interruption occurs, the
`except BaseException` branch at lines 176–181 records uncertainty and re-raises.
It neither drains the already-created child nor transfers its completion handle
to a retained supervisor. `main`, lines 193–202, then returns failure for ordinary
exceptions; interrupt-like exceptions can exit directly.

The child can therefore remain alive and continue the fixed sequence after the
wrapper exits, without an established owner retaining its completion capability.
A PID and an `uncertain` status record describe the problem but do not themselves
retain/join completion or establish a supervision handoff. The comment at line
177 claiming the outcome remains explicitly owned is unsupported by this path.
No native capability violation was observed: **this is a prospective wrapper
source defect**, identified before execution. It blocks wrapper admission because
the one-shot protocol requires owned execution, failure observation and honest
teardown before an uncertain result can end supervision.

## Mocked-test coverage limit

The existing log/result records five mocked tests passed, zero failures/errors,
zero actual model spawns. The tested success path confirms an exclusive persisted
claim precedes spawn; reentry refuses. Other tests preserve child exit 1, refusal
before input reads, formal verification failure, and `Popen` itself raising.

The uncertain-launch test makes `Popen` raise before a child handle is returned.
It does not cover failure after successful `Popen`, a running-status write error,
an interrupted/failed `wait`, or explicit retention/drain of an existing child.
The passing five-test result therefore does not discharge this finding. This
reviewer inspected the source and existing results and ran no additional tests.

## Deferred remedy and stopped boundary

A future proposal would need an explicit policy and implementation retaining the
live child's completion ownership across post-spawn wrapper failures, with
observed drain or a concrete supervision handoff and honest uncertain outcome.
It must not invent termination, cleanup ACK, reuse or retry authority. Model-free
tests should inject errors after successful spawn and demonstrate ownership and
failure observation. These are **pending coordination items**, not authorization
to repair this attempt or rerun any preflight/model protocol.

No formal `one_shot.py verify` or `execute` command was invoked by this reviewer.
No process/model/native cohort was launched, no original SQLite database opened,
and no source, wrapper or test was edited. The only write was this review.
The actual binary and full pre-run freeze had not been available for independent
admission when the finding was raised. An already-running offline build may be
retained as supporting evidence by the parent; its completion cannot change this
NOT_ADMITTED verdict or revive this stopped attempt.

The parent's conditional authorization required independent wrapper review and
actual freeze approval; that gate was not met. Native execution, publication and
merge remain held. Original v1/v2 failed evidence and the separate cancellation
supplement are not relabeled or rerun. M4 C4 remains Partial/Blocked.
