"""Synthetic schema checks and read-only rejection of saved failed pressure.

Every positive status/event fixture here is SYNTHETIC. No executable, model,
facade, reference generator or original SQLite store is opened or invoked.
"""
import ast
import copy
import hashlib
import json
from pathlib import Path
import unittest

import prospective_schema as schema
import review_saved_composed as reviewer

HERE = Path(__file__).resolve().parent
OLD = Path('/workspace/m4-main-v2-review/review_saved_main.py')
V2 = Path('/workspace/m4-main-v2')


class Preflight(unittest.TestCase):
    def setUp(self):
        self.argv = ['/SYNTHETIC/binary', '/SYNTHETIC/main', '--serial-residency']
        self.freeze = dict(protocol=schema.PROTOCOL, producer_protocol=schema.PRODUCER_PROTOCOL,
                           source_head=schema.HEAD, source_tree=schema.TREE, binary_sha256='a' * 64)
        self.status = dict(self.freeze, state='completed', exit_code=0, attempt=1,
                           retry_allowed=False, argv=self.argv,
                           started_utc='2000-01-01T00:00:00+00:00',
                           completed_utc='2000-01-01T00:00:01+00:00')
        self.run = 'SYNTHETIC-pressure-run-NOT-AN-OBSERVATION'
        self.cause = 'SYNTHETIC headroom admission refusal'
        self.error = 'internal: ' + self.cause
        self.events = [
            dict(event_seq=1, node_id=None, workflow_run_id=self.run,
                 payload=dict(payload_type='run_snapshot_accepted')),
            dict(event_seq=5, node_id=None, workflow_run_id=self.run,
                 payload=dict(payload_type='run_terminal', duration_ms=0,
                              status='failed', error=self.cause)),
        ]

    def test_synthetic_completed_status_shape_only(self):
        self.assertIs(schema.validate_status([self.status], self.freeze, self.argv), self.status)

    def test_status_negative_boundaries(self):
        cases = [
            ('state', 'running', 'not completed'),
            ('exit_code', 1, 'not completed'),
            ('exit_code', False, 'not completed'),
            ('attempt', 2, 'attempt=1'),
            ('attempt', True, 'attempt=1'),
            ('retry_allowed', True, 'retry permission'),
            ('source_head', '0' * 40, 'wrong composed source'),
            ('source_tree', '0' * 40, 'wrong composed source'),
            ('binary_sha256', 'b' * 64, 'wrong binary'),
            ('protocol', schema.PRODUCER_PROTOCOL, 'wrong cohort protocol'),
            ('producer_protocol', schema.PROTOCOL, 'legacy producer label'),
            ('argv', ['/SYNTHETIC/other'], 'execution scope'),
            ('started_utc', '', 'missing started_utc'),
            ('started_utc', 'invalid', 'invalid UTC timestamp'),
            ('started_utc', '2000-01-01T00:00:00', 'timestamp must be UTC'),
            ('completed_utc', '1999-01-01T00:00:00+00:00', 'completion must follow start'),
        ]
        for key, value, reason in cases:
            with self.subTest(key=key, value=value):
                status = copy.deepcopy(self.status)
                status[key] = value
                with self.assertRaisesRegex(AssertionError, reason):
                    schema.validate_status([status], self.freeze, self.argv)

    def test_missing_and_ambiguous_attempt(self):
        for keep in (False, True):
            with self.subTest(keep_canonical_attempt=keep):
                status = copy.deepcopy(self.status)
                if not keep:
                    del status['attempt']
                status['attempt_within_v2'] = 1
                with self.assertRaisesRegex(AssertionError, 'attempt'):
                    schema.validate_status([status], self.freeze, self.argv)

    def test_missing_and_duplicate_status(self):
        for statuses in ([], [self.status, self.status]):
            with self.subTest(count=len(statuses)):
                with self.assertRaisesRegex(AssertionError, 'exactly one execution status'):
                    schema.validate_status(statuses, self.freeze, self.argv)

    def test_binary_freeze_mismatch_and_missing_hash(self):
        for key, value, reason in [('source_head', '0' * 40, 'binary freeze belongs'),
                                   ('binary_sha256', None, 'actual frozen binary')]:
            with self.subTest(key=key):
                freeze = copy.deepcopy(self.freeze)
                freeze[key] = value
                with self.assertRaisesRegex(AssertionError, reason):
                    schema.validate_status([self.status], freeze, self.argv)

    def test_synthetic_pressure_terminal_shape_only(self):
        self.assertIs(schema.validate_pressure_terminal(self.events, self.run, self.error), self.events[1])

    def test_pressure_negative_boundaries(self):
        cases = [
            ('missing', 'one matching raw pressure terminal'),
            ('duplicate', 'one matching raw pressure terminal'),
            ('foreign_run', 'one matching raw pressure terminal'),
            ('completed', 'workflow Failed terminal'),
            ('node_terminal', 'workflow Failed terminal'),
            ('missing_error', 'preserve the actual public failure'),
            ('foreign_error', 'preserve the actual public failure'),
            ('before_admission', 'follow admission'),
            ('missing_snapshot', 'matching admitted run snapshot'),
            ('started', 'must not create'),
            ('completed_attempt', 'must not create'),
        ]
        for name, reason in cases:
            with self.subTest(case=name):
                events = copy.deepcopy(self.events)
                if name == 'missing':
                    events.pop()
                elif name == 'duplicate':
                    events.append(copy.deepcopy(events[1]))
                elif name == 'foreign_run':
                    events[1]['workflow_run_id'] = 'SYNTHETIC-foreign'
                elif name == 'completed':
                    events[1]['payload']['status'] = 'completed'
                elif name == 'node_terminal':
                    events[1]['node_id'] = 'infer'
                elif name == 'missing_error':
                    events[1]['payload']['error'] = None
                elif name == 'foreign_error':
                    events[1]['payload']['error'] = 'SYNTHETIC different error'
                elif name == 'before_admission':
                    events[1]['event_seq'] = 0
                elif name == 'missing_snapshot':
                    events.pop(0)
                else:
                    events.insert(1, dict(event_seq=2, node_id='infer', workflow_run_id=self.run,
                        payload=dict(payload_type='scheduler_task_attempt_lifecycle_changed',
                                     transition='started' if name == 'started' else 'completed')))
                with self.assertRaisesRegex(AssertionError, reason):
                    schema.validate_pressure_terminal(events, self.run, self.error)

    def test_real_v2_pressure_still_rejected_without_sqlite_or_native(self):
        events = json.loads((V2 / 'main/pressure/events.json').read_text())
        row = json.loads((V2 / 'main/pressure/step-0.json').read_text())
        run = events[0]['workflow_run_id']
        with self.assertRaisesRegex(AssertionError, 'one matching raw pressure terminal'):
            schema.validate_pressure_terminal(events, run, row['error'])

    def test_owner_oracle_preserved_except_added_pressure_guard(self):
        def owner_tree(path):
            tree = ast.parse(path.read_text())
            return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'verify_owner')
        original = owner_tree(OLD)
        current = owner_tree(HERE / 'review_saved_composed.py')
        class RemoveAddedGuard(ast.NodeTransformer):
            def visit_Expr(self, node):
                if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'validate_pressure_terminal':
                    return None
                return self.generic_visit(node)
        current = RemoveAddedGuard().visit(current)
        self.assertEqual(ast.dump(original, include_attributes=False), ast.dump(current, include_attributes=False))
        self.assertEqual(reviewer.WORK, [8, 8, 12, 12, 8])
        self.assertEqual(reviewer.TASK, {8: 536895107, 12: 536908694})
        self.assertEqual((reviewer.GUARD, reviewer.RESIDENT), (48 * 1024**2, 32 * 1024**2))


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Preflight)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = dict(kind='MODEL-FREE SYNTHETIC SCHEMA PREFLIGHT ONLY',
                  test_methods=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                  passed=result.wasSuccessful(), synthetic_positive_fixtures=True,
                  actual_v2_pressure_remains_failed=True, native_qualified=False,
                  native_invocations=0, original_sqlite_opened=False,
                  production_source_changed=False)
    (HERE / 'preflight-result.json').write_text(json.dumps(report, indent=2) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
