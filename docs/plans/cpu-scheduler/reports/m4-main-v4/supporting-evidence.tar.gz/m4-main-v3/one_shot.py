"""One admitted local M4 invocation. Import/--verify never executes the probe.

No retry, cleanup, download, publication or forced process termination exists.
An exclusive claim is persisted before spawn; any uncertain launch consumes it.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/m4-main-v3')
REPO = Path('/workspace/pantograph-m4-composed')
HEAD = '9ce4ca8aca004cf51782c59e91dd9fd7af5beed5'
TREE = '05c47e8ca113fcd400d9c21bf9b6eb121555f1bc'
PROTOCOL = 'm4-serial-residency-v3-lifecycle'
PRODUCER = 'm4-serial-residency-v2-readback'


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(value, message):
    if not value:
        raise AssertionError(message)


def verify_inputs(root):
    require(root == ROOT, 'wrong qualification destination')
    require(not any((root / p).exists() for p in
                    ('invocation-claim.json', 'execution-status.json',
                     'preflight-failure.json', 'main', 'process.log')),
            'existing invocation/output/failure refuses execution')
    for relative, digest in read(root / 'pre-run-manifest-sha256.json').items():
        path = root / relative
        require(path.resolve().is_relative_to(root.resolve()) and sha(path) == digest,
                'frozen input changed: ' + relative)
    source = read(root / 'source-freeze.json')
    require(source['head'] == HEAD and source['tree'] == TREE, 'wrong source freeze')
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                    text=True).strip() == HEAD, 'source head changed')
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO,
                                    text=True).strip() == TREE, 'source tree changed')
    require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO),
            'source worktree is dirty')
    for name, digest in source['source_sha256'].items():
        require(sha(REPO / name) == digest, 'source file changed: ' + name)
    fixture = read(root / 'fixture-freeze.json')
    require(len(fixture['fixture_file_sha256']) == 14, 'fixture count changed')
    require(all(sha(REPO / 'crates/inference/tests/fixtures/candle_bert' / p) == digest
                for p, digest in fixture['fixture_file_sha256'].items()), 'fixture changed')
    require(all(m['text'] == 'hello world' for m in fixture['models'].values()),
            'fixed input changed')
    binary = read(root / 'binary-freeze.json')
    expected_argv = [str(root / 'binaries/frozen-cpu-embedding-workflow-probe'),
                     str(root / 'main'), '--serial-residency']
    require(binary['source_head'] == HEAD and binary['source_tree'] == TREE
            and binary['protocol'] == PROTOCOL and binary['producer_protocol'] == PRODUCER
            and binary['profile'] == 'release' and binary['default_features'] is False
            and set(binary['features']) == {'backend-candle', 'host-dependency-inventory'}
            and binary['build_exit'] == 0 and binary['attempts'] == 1
            and binary['retries_allowed'] is False and binary['argv'] == expected_argv,
            'binary scope changed')
    require(binary['binary_path'] == expected_argv[0]
            and sha(Path(binary['binary_path'])) == binary['binary_sha256'],
            'actual release binary changed')
    auth = read(root / 'authorization.json')
    require(auth['source_head'] == HEAD and auth['source_tree'] == TREE
            and auth['protocol'] == PROTOCOL and auth['producer_protocol'] == PRODUCER
            and auth['run_once'] is True and auth['retry_allowed'] is False
            and auth['downloads'] is False and auth['external_transmission'] is False
            and auth['native_scope'] == {'retained': [8, 8, 12, 12, 8],
                                        'comparisons': [8, 8, 12, 12, 8], 'pressure': [8],
                                        'text': 'hello world', 'new_cancellation_cases': 0},
            'parent admission scope changed')
    accounting = read(root / 'accounting-freeze.json')
    mib = 1024**2
    require(accounting['main'] == dict(declared_guard_ram_bytes=48*mib,
                declared_guard_vram_bytes=0, declared_resident_ram_bytes=32*mib,
                declared_resident_vram_bytes=0, ram_capacity_bytes=1104*mib,
                vram_capacity_bytes=1024*mib, safety_margin_bytes_per_kind=0),
            'main envelopes changed')
    require(accounting['pressure']['ram_capacity_bytes'] == 80*mib
            and accounting['pressure']['vram_capacity_bytes'] == 1024*mib,
            'pressure envelopes changed')
    for width, size in ((8, 536895107), (12, 536908694)):
        model = accounting['models'][str(width)]
        require(model['expected_actual_intent_ram_max_bytes']
                == model['expected_actual_intent_vram_max_bytes'] == size,
                'authoritative task maxima changed')
    environment = read(root / 'environment-freeze.json')
    require(environment['protocol'] == PROTOCOL and environment['producer_protocol'] == PRODUCER
            and environment['cpu_threads_per_private_gateway'] == 1
            and environment['attempts'] == 1 and environment['retries'] == 0
            and environment['cancellation_cases_in_this_invocation'] == 0
            and environment['cpu_affinity'] == sorted(os.sched_getaffinity(0)),
            'runtime environment scope changed')
    for name, value in environment['cgroup'].items():
        path = Path('/sys/fs/cgroup') / name
        require((path.read_text().strip() if path.exists() else None) == value,
                'cgroup changed: ' + name)
    for name, value in environment['inherited_thread_offline_controls'].items():
        require(os.environ.get(name) == value, 'inherited control changed: ' + name)
    require(environment['fixed_runtime_env'] == {
        'ORT_SKIP_DOWNLOAD': '1', 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
        'TOKENIZERS_PARALLELISM': 'false', 'PUMAS_REGISTRY_DB_PATH': str(root/'main/registry.db')},
        'offline/registry controls changed')
    require(environment['explicit_runtime_unsets'] == ['PANTOGRAPH_CPU_EMBEDDING_FIXTURE_ROOT'],
            'fixture override exclusion changed')
    for path, digest in read(root / 'preservation-freeze.json')['files'].items():
        require(sha(Path(path)) == digest, 'prior evidence changed: ' + path)
    admission = read(root / 'review/independent-admission.json')
    require(admission['approved'] is True and admission['source_head'] == HEAD
            and admission['source_tree'] == TREE
            and admission['binary_sha256'] == binary['binary_sha256']
            and admission['wrapper_sha256'] == sha(root / 'one_shot.py')
            and admission['reviewer_sha256'] == sha(root / 'review/review_saved_composed.py')
            and admission['schema_sha256'] == sha(root / 'review/prospective_schema.py'),
            'independent wrapper/freeze admission absent or stale')
    return binary, environment


def write_status(root, status, initial=False):
    target = root / 'execution-status.json'
    if initial:
        with target.open('x') as stream:
            json.dump(status, stream, indent=2)
            stream.write('\n')
    else:
        temporary = root / 'execution-status.next.json'
        with temporary.open('x') as stream:
            json.dump(status, stream, indent=2)
            stream.write('\n')
        os.replace(temporary, target)


def run_once(root):
    binary, environment = verify_inputs(root)
    status = dict(protocol=PROTOCOL, producer_protocol=PRODUCER, source_head=HEAD,
                  source_tree=TREE, binary_sha256=binary['binary_sha256'],
                  argv=binary['argv'], attempt=1, retry_allowed=False,
                  started_utc=now(), state='starting')
    # Durable exclusive claim precedes spawn. Reentry cannot repair or reuse it.
    with (root / 'invocation-claim.json').open('x') as claim:
        json.dump(status | {'wrapper_sha256': sha(root/'one_shot.py')}, claim, indent=2)
        claim.flush()
        os.fsync(claim.fileno())
    write_status(root, status, initial=True)
    env = os.environ.copy()
    env.update(environment['fixed_runtime_env'])
    for key in environment['explicit_runtime_unsets']:
        env.pop(key, None)
    try:
        with (root / 'process.log').open('xb') as stream:
            child = subprocess.Popen(binary['argv'], cwd=REPO, env=env,
                                     stdout=stream, stderr=subprocess.STDOUT)
            status.update(state='running', pid=child.pid)
            write_status(root, status)
            code = child.wait()
        status.update(state='completed', exit_code=code, completed_utc=now())
        write_status(root, status)
        return code
    except BaseException as error:
        # No kill/retry: unknown child/teardown outcome remains explicitly owned.
        status.update(state='uncertain', wrapper_error=f'{type(error).__name__}: {error}',
                      observed_utc=now())
        write_status(root, status)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('verify', 'execute'))
    args = parser.parse_args()
    try:
        if args.mode == 'verify':
            verify_inputs(ROOT)
            print('Actual source/binary/input/environment/review freeze verified; no invocation.')
            return 0
        return run_once(ROOT)
    except Exception as error:
        # A failed formal preflight is permanent for this admitted attempt.
        target = ROOT/'preflight-failure.json'
        if not (ROOT/'invocation-claim.json').exists() and not target.exists():
            with target.open('x') as stream:
                json.dump({'state':'preflight_failed','error':f'{type(error).__name__}: {error}',
                           'time_utc':now(),'native_invocations':0,'retry_allowed':False}, stream, indent=2)
        print(f'Qualification stopped: {type(error).__name__}: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
