"""Synthetic wrapper tests only. Popen is always replaced; no model executes.

Disposable fixture outputs remain under validation/wrapper-fixtures; no cleanup
or modifications of a real evidence root occur here.
"""
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import one_shot as wrapper

HERE = Path(__file__).resolve().parent


class FakeChild:
    pid = 101

    def __init__(self, code=0):
        self.code = code

    def wait(self):
        return self.code


class WrapperTests(unittest.TestCase):
    def setUp(self):
        self.root = HERE/'validation/wrapper-fixtures'/self._testMethodName
        self.root.mkdir(parents=True, exist_ok=False)
        (self.root/'one_shot.py').write_text('SYNTHETIC WRAPPER FIXTURE; NEVER EXECUTABLE\n')
        self.binary = {'binary_sha256':'a'*64,
                       'argv':['/SYNTHETIC/NEVER-EXECUTED',str(self.root/'main'),'--serial-residency']}
        self.env = {'fixed_runtime_env':{'HF_HUB_OFFLINE':'1'},
                    'explicit_runtime_unsets':['PANTOGRAPH_CPU_EMBEDDING_FIXTURE_ROOT']}

    def fake_spawn(self, *args, **kwargs):
        self.assertTrue((self.root/'invocation-claim.json').is_file())
        self.assertEqual(json.loads((self.root/'execution-status.json').read_text())['state'], 'starting')
        self.assertEqual(args[0], self.binary['argv'])
        self.assertNotIn('shell', kwargs)
        self.assertEqual(kwargs['env']['HF_HUB_OFFLINE'], '1')
        self.assertNotIn('PANTOGRAPH_CPU_EMBEDDING_FIXTURE_ROOT', kwargs['env'])
        return FakeChild()

    def test_claim_precedes_one_spawn_and_reentry_refuses(self):
        with patch.object(wrapper,'verify_inputs',return_value=(self.binary,self.env)), \
             patch.object(wrapper.subprocess,'Popen',side_effect=self.fake_spawn) as spawn:
            self.assertEqual(wrapper.run_once(self.root),0)
            with self.assertRaises(FileExistsError):
                wrapper.run_once(self.root)
            self.assertEqual(spawn.call_count,1)
        status=json.loads((self.root/'execution-status.json').read_text())
        self.assertEqual((status['state'],status['exit_code'],status['attempt']),('completed',0,1))
        self.assertIs(status['retry_allowed'],False)

    def test_child_failure_is_preserved_without_retry(self):
        with patch.object(wrapper,'verify_inputs',return_value=(self.binary,self.env)), \
             patch.object(wrapper.subprocess,'Popen',return_value=FakeChild(1)) as spawn:
            self.assertEqual(wrapper.run_once(self.root),1)
            self.assertEqual(spawn.call_count,1)
        self.assertEqual(json.loads((self.root/'execution-status.json').read_text())['exit_code'],1)

    def test_uncertain_launch_consumes_claim_without_retry(self):
        with patch.object(wrapper,'verify_inputs',return_value=(self.binary,self.env)), \
             patch.object(wrapper.subprocess,'Popen',side_effect=OSError('SYNTHETIC launch failure')) as spawn:
            with self.assertRaises(OSError):
                wrapper.run_once(self.root)
            with self.assertRaises(FileExistsError):
                wrapper.run_once(self.root)
            self.assertEqual(spawn.call_count,1)
        self.assertEqual(json.loads((self.root/'execution-status.json').read_text())['state'],'uncertain')

    def test_formal_preflight_failure_records_no_invocation(self):
        with patch.object(wrapper,'ROOT',self.root), \
             patch.object(sys,'argv',['one_shot.py','verify']), \
             patch.object(wrapper,'verify_inputs',side_effect=AssertionError('SYNTHETIC mismatch')), \
             patch.object(wrapper.subprocess,'Popen') as spawn:
            self.assertEqual(wrapper.main(),1)
            spawn.assert_not_called()
        self.assertTrue((self.root/'preflight-failure.json').is_file())
        self.assertFalse((self.root/'invocation-claim.json').exists())

    def test_existing_failure_or_output_refuses_before_input_reads(self):
        (self.root/'preflight-failure.json').write_text('{"kind":"SYNTHETIC"}\n')
        with patch.object(wrapper,'ROOT',self.root):
            with self.assertRaisesRegex(AssertionError,'existing invocation/output/failure'):
                wrapper.verify_inputs(self.root)


if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(WrapperTests))
    (HERE/'validation/wrapper-test-result.json').write_text(json.dumps({
        'kind':'SYNTHETIC MOCKED WRAPPER TESTS ONLY','tests':result.testsRun,
        'passed':result.wasSuccessful(),'failures':len(result.failures),'errors':len(result.errors),
        'actual_model_spawns':0,'native_qualified':False},indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
