# Process supervision clarification

This clarification supersedes the sentence in `REPORT.md` that says “All three process groups were reaped.” The precise supported statement is:

**All three direct children were reaped, and a subsequent `/proc` readback found no live process-group members. Descendant reaping is not claimed.**

The supervisor's raw records explicitly make this distinction. Its process-containment result is separate from native ownership/release evidence. The pre-Start case retains an honest full fence; the post-drain case records exact task-release acknowledgement/cap return and subsequent stop/charge clearing. The three passing local regression results and all other report limitations are unchanged.

The original report, its 35-file manifest and the initial 36-member archive remain byte-for-byte preserved. This addendum is included in the separately sealed reviewed evidence package; no raw execution file or source was changed and no case was rerun.
