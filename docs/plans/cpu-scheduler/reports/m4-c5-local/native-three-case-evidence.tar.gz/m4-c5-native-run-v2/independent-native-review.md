# Independent native evidence review

Accepted: the exactly authorized three local native regression cases passed once at source `be7773eebe5b931372425516c29825d71b808503`, tree `beffc99b779c86c7890e19b9247ccbf5011c7fe9`. This is narrow local regression evidence, not broader C5 or hosted qualification. No material evidence finding remains.

The original 28 execution files match manifest SHA256 `be10abc3677fdb1f42f3059ef11c03d0f04db09b248d30da62544ea0a9a8dbef`. Review artifacts and subsequently copied admission/protocol provenance are outside that execution manifest. All 49 frozen inputs, 52 final protocol files, 2,446 source hashes, 1,256 historical hashes, both immutable binaries and seven fixture files remain unchanged. The be777, 470775, qualified 9ce and e792 worktrees retain exact clean heads and trees. The prior failed model-free attempt remains failed; the accepted second nine-case model-free result remains separate and historical at 470775.

## Launch, oracle and process evidence

The saved actual tool terminal objects report preflight outer exit zero (initial session 9620, terminal chunk 855733) and execute outer exit zero (initial session 21329, terminal chunk 890135). Their actual command and workdir match the frozen verify/execute plans. The launch witnesses match literal `/usr/bin/python3`, resolved Python 3.13, executable SHA256 and exact version, complete argv, cwd, source and admission. The actual external admission correctly binds launcher SHA256 `730205ad60d030c45eb70d1c7778d98a6b2f4c9bb6ce27f8d2e45e9b69cd46b1` and final manifest `bb8ff6d36ed571c99b26ce877edc936de35f97d46fbed9e3f09344c1fb0ee8b6`; the preserved descriptive schema's stale example was not used. Outer success is based on actual saved terminal records and parent-reported tool provenance, not inferred from inner status.

Each child claim/process record matches the frozen prlimit argv, exact selected test, inventory executable, cwd and no-retry scope. Each log independently reports one selected test passed, zero failed/ignored and 610 filtered out. All three final source oracles are true. The suite reports three passed and zero failed. No stage-failure marker or second invocation is present in the reviewed run.

Each child exited zero, was reaped and completed process cleanup, with no supervisor errors, signals or retained owner. Recorded PIDs/process groups are 76743, 76758 and 76773; an independent /proc readback found no live member in those groups. This process containment evidence does not establish native task acknowledgement; native branches are assessed below.

Recorded sampled group RSS maxima were 110,358,528 / 107,913,216 / 111,185,920 bytes, with 33 / 20 / 26 samples. Recorded output-tree maxima were 2,013,466 / 1,208,058 / 1,541,377 bytes. These stayed within the frozen sampled bounds. The fixed hard resource limits and original source timeouts were used. These observations are neither precise peaks nor a performance or capacity benchmark.

## Facade execution and retained shutdown owner

The facade log passes the original test; the source-bound 16 assertions retain two distinct real runs, eight-element golden comparisons at the original tolerance, one genuine load, one retain, exact guard/task ownership and acknowledged/idempotent shutdown, including retained shutdown supervision after its original caller is dropped. Raw vectors/counter snapshots are not exported by the facade JSON, so these particular facts remain source-assisted assertion evidence rather than independent raw vector/counter measurements.

The progress file is newline terminated and has exactly 27 contiguous sequence records, zero through 26, starting with case_started and ending with oracle_completed/ok. It records the actual attributed session, distinct workflow run IDs for round zero and round one, both successful round results, successful body and successful owned shutdown. Final JSON explicitly has diagnostic_io_error null and host dependency inventory true. No first terminal error or terminal-error journal event exists. The first/latest observed error is ordinary RuntimeDependencyReadinessPending during physical_run; its subsequent resume and both round completions show it was preliminary readiness polling, not a terminal cause.

The journal demonstrates successful durable public-call progress for this run. It does not test recovery from an actual hung shutdown, blocked fsync or failed storage, and its phases do not expose hidden internal awaits. Private raw Check/request/binding/provider readiness remains unavailable.

## Pre-Start shutdown: expected full fence

The held boundary has one genuine native load, zero forward drains and zero stops. Task infer is Ready with no active attempt. The guard reservation is 1, owned by `serial-preparation.6adeb2eb-ae29-4381-907d-82dc7d69052b`; Candle instance is candle-1. Its exact 629,145,600-byte RAM preparation claim and 33,554,432-byte resident RAM claim, with zero VRAM claims, remain unchanged through shutdown and final snapshot.

The owned shutdown signal was requested while the native gate was held. The run then reports that completed native load before Start stopped for shutdown because the owner is closing; shutdown reports fenced-owner refusal. These are the expected successful negative oracle. Final native evidence remains fenced, without idle owner, with one load, zero drains and zero stops. The raw ledger records the run's failed terminal event and no inference Running attempt. This result proves the reported safety fence for this boundary; it does not prove acknowledged physical release or zero retained accounting. Process exit must not be substituted for native ACK.

## Post-drain cancellation: completion won, exact release observed

The held boundary records one genuine load and one drained forward while task infer is publicly Running. Workflow run is `run_89bff15c-0ae0-4f2a-88d8-f8556c8bcd42`, attempt `scheduler-task-attempt.06d57eb9-7c2c-4e68-a15d-c997bb562840`. Guard lease 1 and task lease 3 are distinct. The task lease owner is that actual run plus infer; its RAM and VRAM accounting claims are each 536,895,107 bytes. These are scheduler accounting declarations, not GPU execution or measured device memory.

The public cancellation response targets the same active attempt and reports cancellation_requested. Immediately afterward the actual attempt is still Running and every registry lease/claim/resident field equals the held-boundary snapshot. Cancellation itself releases no charge. After the receipt is released, the actual run succeeds and its terminal projection/ledger says completed; cancellation did not win and no in-flight interruption is claimed.

The recorded branch is exact_task_release_ack_and_cap_returned: the after-run registry equals the expected snapshot obtained by removing only task lease/claim 3 while preserving guard 1 and resident accounting. Native state has the returned idle owner and no fence. The raw completed-attempt event matches the actual attempt and reservation runtime-registry.3. The metadata projection refresh preserves native accounting and cannot supply this ACK. Subsequent shutdown succeeds once, native stops is one, no idle owner/fence remains, all leases/active/resident claims are empty and both runtimes are stopped. The selected exact-cleanup branch passed; the alternate full-fence branch was not exercised in this case.

## Limits of the finding

Both cancellation evidence documents retain actual first/latest errors, physical-await labels, resume identities and bounded gate/final raw ledgers. Those ledger pages are not truncated (within 128 rows). Closed-admission errors in final public task/scheduler queries after shutdown are expected metadata limitations; they do not negate the separately captured native/registry/terminal evidence. The first Pending observation in each case is not a historical or current terminal root cause.

The original hosted PR83/PR84 failures and their known merge-checkout provenance remain preserved. This controlled host-inventory-enabled local result does not reconstruct their missing first readiness results or prove their exact root cause. Default physical execution remains unsupported without inventory; default negative/metadata/projection coverage is preserved as historical accepted model-free evidence, not rerun here. No overall M4/C5, exact published-head CI, GPU, batching, trained-model, production or performance qualification follows.

This reviewer performed saved-data/source/hash/status/process inspection only, with no Cargo, native/model test, formal launcher action, retry, source edit or frozen-evidence mutation. Future native attempts, repairs or broader execution require separate authorization; this completed attempt supplies no rerun authority.
