"""Model-free command/observer checks; never invokes a Pantograph binary."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import native_launcher as launcher
from owned_process import OwnedChild


class LauncherBoundaryTests(unittest.TestCase):
    def test_missing_admission_cannot_spawn_or_create_run_root(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            with mock.patch.object(launcher,'ADMISSION',root/'absent.json'), mock.patch.object(launcher,'RUN',root/'run'), \
                 mock.patch.object(launcher.sys,'argv',['native_launcher.py','execute']), \
                 mock.patch.object(launcher,'OwnedChild',side_effect=AssertionError('must not spawn')), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(launcher.main(),2)
                self.assertFalse((root/'run').exists())

    def test_owned_preflight_input_failure_blocks_execute_reentry(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);run=root/'run';run.mkdir();receipt=root/'admission';receipt.write_text('{}')
            (run/'preflight.json').write_text(json.dumps({'head':'h','tree':'t','admission_sha256':launcher.sha(receipt)}))
            with mock.patch.object(launcher,'ADMISSION',receipt), mock.patch.object(launcher,'RUN',run), \
                 mock.patch.object(launcher.sys,'argv',['native_launcher.py','execute']), \
                 mock.patch.object(launcher,'admission',return_value={'head':'h','tree':'t'}), \
                 mock.patch.object(launcher,'verify_inputs',side_effect=AssertionError('source changed')) as verify, \
                 mock.patch.object(launcher,'OwnedChild',side_effect=AssertionError('must not spawn')), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(launcher.main(),1)
                failure=(run/'stage-failure.json').read_bytes()
                self.assertEqual(launcher.main(),1)
                self.assertEqual(verify.call_count,1)
                self.assertEqual((run/'stage-failure.json').read_bytes(),failure)

    def test_unsupported_action_cannot_read_admission_or_spawn(self):
        with mock.patch.object(launcher.sys,'argv',['native_launcher.py','other']), \
             mock.patch.object(launcher,'admission',side_effect=AssertionError('must not read')), \
             mock.patch.object(launcher,'OwnedChild',side_effect=AssertionError('must not spawn')), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(launcher.main(),2)

    def test_rss_sums_only_live_matching_process_group(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            for pid,state,group,rss in [(1,'S',50,17),(2,'S',50,23),(3,'Z',50,999),(4,'S',99,999)]:
                p=root/str(pid);p.mkdir();(p/'stat').write_text(f'{pid} (with spaces) {state} 0 {group} 0\n');(p/'status').write_text(f'VmRSS:\t{rss} kB\n')
            self.assertEqual(launcher.group_rss(50,root),40*1024)

    def test_unavailable_rss_is_not_treated_as_zero(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);p=root/'1';p.mkdir();(p/'stat').write_text('1 (x) S 0 50 0\n');(p/'status').write_text('Name: x\n')
            with self.assertRaisesRegex(AssertionError,'RSS observation unavailable'):
                launcher.group_rss(50,root)

    def test_output_monitor_rejects_symlinks(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'actual').write_bytes(b'abc');self.assertEqual(launcher.output_bytes(root),3)
            (root/'alias').symlink_to(root/'actual')
            with self.assertRaisesRegex(AssertionError,'unsafe'):
                launcher.output_bytes(root)

    def test_complete_contiguous_journal_only(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'journal'
            rows=[{'sequence':0,'event':'case_started','data':{}},{'sequence':1,'event':'oracle_completed','data':{'ok':True}}]
            data=''.join(json.dumps(x)+'\n' for x in rows);p.write_text(data)
            self.assertEqual(launcher.journal(p),rows)
            p.write_text(data[:-1])
            with self.assertRaisesRegex(AssertionError,'incomplete'):
                launcher.journal(p)
            rows[1]['sequence']=2;p.write_text(''.join(json.dumps(x)+'\n' for x in rows))
            with self.assertRaisesRegex(AssertionError,'sequence'):
                launcher.journal(p)

    def test_oracle_true_does_not_mask_diagnostic_io_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'evidence').mkdir();name=launcher.TESTS[0].split('::')[-1]
            (root/'test.log').write_text(launcher.TESTS[0]+'\ntest result: ok. 1 passed; 0 failed; 0 ignored;\n')
            evidence={'case_id':name,'oracle':{'ok':True},'host_dependency_inventory':True,'diagnostic_io_error':'disk error'}
            for malformed in (evidence,{key:value for key,value in evidence.items() if key!='diagnostic_io_error'}):
                with self.subTest(missing_field='diagnostic_io_error' not in malformed):
                    (root/'evidence'/(name+'.json')).write_text(json.dumps(malformed))
                    with self.assertRaisesRegex(AssertionError,'diagnostics incomplete'):
                        launcher.validate_case({'test':launcher.TESTS[0],'order':1},root)

    def test_expired_suite_cannot_start_next_native_process(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'cases').mkdir()
            case={'order':1,'test':launcher.TESTS[0],'argv':['must-not-spawn'],'cwd':temp,'env_set':{},'env_unset':[]}
            with mock.patch.object(launcher,'RUN',root), mock.patch.object(launcher,'OwnedChild',side_effect=AssertionError('must not spawn')) as spawn:
                with self.assertRaises(launcher.CaseFailure):
                    launcher.execute_case(case,-1)
                self.assertEqual(spawn.call_count,0)
            result=json.loads((root/'cases/01/process-result.json').read_text())
            self.assertIn('before native spawn',result['errors'][0])

    def test_late_already_completed_child_cannot_bypass_case_deadline(self):
        class Finished:
            returncode=0
            done=mock.Mock(is_set=lambda:True)
            def finish_bounded(self,stop=False):
                return {'process_reaped':True,'cleanup_complete':True,'supervisor_retained':False,'errors':[],'signals':[]}
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'cases').mkdir()
            case={'order':1,'test':launcher.TESTS[0],'argv':['synthetic-never-executed'],'cwd':temp,'env_set':{},'env_unset':[]}
            with mock.patch.object(launcher,'RUN',root), mock.patch.object(launcher,'OwnedChild',return_value=Finished()), \
                 mock.patch.object(launcher.time,'monotonic',side_effect=[0,0,421]):
                with self.assertRaises(launcher.CaseFailure):
                    launcher.execute_case(case,2000)
            result=json.loads((root/'cases/01/process-result.json').read_text())
            self.assertIn('terminal case/suite',result['errors'][0])

    def test_suite_deadline_includes_preflight_and_elapsed_inter_action_time(self):
        self.assertEqual(launcher.suite_deadline(100,200),1480)
        for now in (99,1481):
            with self.assertRaisesRegex(AssertionError,'elapsed/clock changed'):
                launcher.suite_deadline(100,now)

    def test_child_failure_exit_mapping_preserves_positive_status(self):
        self.assertEqual(launcher.CaseFailure('failed',101).exit_code,101)
        self.assertEqual(launcher.CaseFailure('signal',-9).exit_code,1)

    def test_prlimit_applies_exact_caps_to_harmless_python_helper(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'helper.log';owner=None
            argv=['/usr/bin/prlimit','--as=4294967296:4294967296','--fsize=8388608:8388608','--core=0:0','--','/usr/bin/python3','-c',
                  'import json,resource; print(json.dumps([resource.getrlimit(x) for x in (resource.RLIMIT_AS,resource.RLIMIT_FSIZE,resource.RLIMIT_CORE)]))']
            with path.open('xb') as output:
                try:
                    owner=OwnedChild(argv,cwd=temp,env={},stdout=output)
                    complete=owner.done.wait(timeout=5)
                finally:
                    cleanup=owner.finish_bounded(stop=not owner.done.is_set()) if owner is not None else None
            self.assertTrue(complete);self.assertEqual(owner.returncode,0)
            self.assertTrue(cleanup['process_reaped'] and cleanup['cleanup_complete'])
            self.assertFalse(cleanup['errors'] or cleanup['signals'] or cleanup['supervisor_retained'])
            self.assertEqual(json.loads(path.read_text()),[[4294967296]*2,[8388608]*2,[0,0]])


if __name__=='__main__':
    unittest.main(verbosity=2)
