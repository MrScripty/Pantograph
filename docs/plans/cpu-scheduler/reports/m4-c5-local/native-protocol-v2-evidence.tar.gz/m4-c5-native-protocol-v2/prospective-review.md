# Independent prospective source, launcher and protocol review

Decision: approve the frozen preparation for the original three-case scope, conditional on fresh explicit native authorization, a separate admission receipt binding the final freeze, and final independent readback. This review does not admit execution. Neither formal native preflight nor execution was invoked; the external admission file and reserved run root are absent.

The reviewed input manifest has 49 entries and SHA256 `984827ddf8e5ca2f7e76346186139d9ce8004f86d3fb3d990834207e73e6340e`. Exact source is `be7773eebe5b931372425516c29825d71b808503`, tree `beffc99b779c86c7890e19b9247ccbf5011c7fe9`. The existing independent facade source review remains part of this input freeze. All 49 input hashes, 2,446 tracked source hashes, 1,256 historical hashes, seven fixture hashes and both immutable executable hashes/modes match. The be777, 470775, qualified 9ce and e792 worktrees retain their exact heads and clean state.

## Source fidelity and diagnostics

Only the existing serial CPU residency test file changes from preserved source 470775: 219 insertions and four deletions, gated by host inventory. The 16 original facade assertions remain in the same order, including two rounds, original 30-second timeouts, golden tolerance and the retained caller-drop shutdown owner. There is no production runtime, admission, default feature or native oracle change.

The exclusive progress journal is opened and its header synchronized before facade creation. Public-call phases, actual round/session/resume identity and changed first/latest errors are synchronized before the next await or shutdown; first terminal error remains distinct from ordinary Pending. The private writer never reopens or truncates earlier progress. Noncritical record/byte exhaustion preserves a critical reserve and still vetoes acceptance. Later diagnostic failures defer their failure until the original cleanup path; initial header failure refuses before facade startup. Source assertion success alone cannot establish diagnostic success.

The launcher now requires the explicit presence of `diagnostic_io_error` with a null value, the host-inventory marker, source oracle success, child exit zero and a complete contiguous journal ending in the source oracle event. A missing field, explicit I/O error, partial journal or missing final JSON fails acceptance. Raw private readiness Check/request/binding/provider snapshots remain unavailable and are never fabricated. Phase labels describe public calls, not every internal await or synchronous operation. Native effectiveness and fsync overhead of this new instrumentation have not been runtime validated; original timeouts remain unchanged.

## Concrete launcher and bounded ownership

The concrete launcher exposes only verify and execute. Both require the external native admission before dispatch or output-root mutation. That receipt must bind the final manifest, source/tree, launcher, unchanged supervisor, commands, explicit authorization reference, exactly three cases and no retry. Literal `/usr/bin/python3`, complete argv, cwd, resolved interpreter, hash and version are checked, preventing the earlier interpreter substitution. Input, source, binary, fixture, historical, CPU/cgroup and inherited environment identities are rechecked before native startup.

Formal verify exclusively claims a new run root after external admission; a failed owned preflight leaves a failure marker. Execute validates that ownership before heavy checks and refuses reentry, missing actual preflight outer-zero, stale inputs and foreign roots. The suite clock starts before formal preflight validation and includes idle time before execute, repeat validation and cases. Expired global time is checked immediately before spawn; terminal elapsed time is checked even for already-completed children.

The unchanged supervisor remains sole waiter and process-group owner. Proposed bounds are 420 seconds per case, 1,380 seconds for the suite, process AS 4 GiB, individual file size 8 MiB, core size zero, sampled live process-group RSS 2 GiB and sampled per-case output tree 64 MiB. The 20 ms monitor rejects missing observations, symlink outputs and excessive entries; terminal output is checked unconditionally after cleanup and after controller metadata. RSS/output polling is not a kernel aggregate cap; the shared cgroup is not exclusive. These new native resource limits have been bootstrap checked only on harmless Python probes, not on the native allocator.

Every accepted case requires exact one-test log success, child zero, reaped/complete supervision without errors, signals or retained owner, and its source evidence. First failure stops later cases. Missing, nonzero or uncertain actual outer terminal results independently veto success and forbid relaunch. Caller capture of actual tool results and independent post-run evidence review remain necessary; inner status files cannot supply that evidence.

## Fixed workload and historical failure mapping

The frozen commands select only the original hosted failures, serially and once:

1. `serial_cpu_residency::tests::actual_facade_session_uses_private_load_owner_and_acknowledged_shutdown`
2. `tests::workflow_run_execution_tests::native_serial_residency_tests::actual_post_load_pre_start_shutdown_signal_fences_guard_without_running_attempt`
3. `tests::workflow_run_execution_tests::native_serial_residency_tests::actual_public_running_post_drain_cancellation_preserves_cap_and_exact_cleanup`

They use only the seven-file committed synthetic, untrained BERT8 fixture and hello world input. Inventory features are explicit; no extra features, model, vector set, cohort or download is authorized. The default binary discovers none of these native cases, while the inventory binary discovers each exactly once.

Historical PR83 and PR84 jobs ran known merge commits a41c8d2e and c89d67db, respectively, and each reported 600 passed, three failed and two ignored. The facade final unwrap reported TerminalFailed; the cancellation final unwraps reported Elapsed. Their actual first failing awaits/readiness results remain unknown. The new controlled regression cannot establish those historical root causes or substitute for exact published-head CI.

Expected pre-Start run/shutdown errors and full retained charges behind an honest fence are the negative oracle, not proof of acknowledged native cleanup. Post-drain source permits exact acknowledgement/cleanup or the documented honest full-fence branch; the actual branch must be reported without asserting a cancellation winner or unconditional stop counts. Process-group cleanup never implies native task acknowledgement. Facade assertions supply source-assisted golden/owner evidence; its final JSON is not a raw vector or native counter export.

## Verification and preserved limits

Saved actual records show both exact-source no-run builds, both scoped no-dependency Clippy checks, formatting and whitespace checks succeeded. Two listings were performed without executing Rust cases. Thirteen distinct launcher policy checks passed across five invocations with method counts 9, 10, 4, 2 and 1; exactly two harmless Python resource-report children ran. Later focused clock/deadline/required-field checks used synthetic inputs and no subprocess. This reviewer read the records and source and performed read-only hashes/status checks; no Cargo, tests, binary listing, model or formal launcher action was run by this reviewer.

The earlier 46-input review draft is preserved and superseded by the current 49-input freeze, including strict required diagnostic-field validation and its focused check. No native attempt occurred under either draft. Accepted default model-free cases remain historical at source 470775; new be777 default source was compiled/listed only. The first model-free attempt remains failed and protocol-inconformant, and the independently accepted second nine-case model-free result is preserved. Qualified local C4 and e792 are unchanged.

No material finding remains against the present prospective freeze. Future execution remains not admitted and not attempted. This review confers no broader C5, hosted CI, production, trained-model, GPU, batching or performance qualification. An archive is a transport of this preparation and does not replace the separately frozen executables or the future authorization/readback gates.
