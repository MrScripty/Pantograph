"""Frozen three-case native observer. No native action without external admission."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from owned_process import OwnedChild

ROOT = Path('/workspace/m4-c5-native-protocol-v2')
RUN = Path('/workspace/m4-c5-native-run-v2')
REPO = Path('/workspace/pantograph-m4-c5-facade')
ADMISSION = Path('/workspace/m4-c5-native-admission-v2.json')
TESTS = (
    'serial_cpu_residency::tests::actual_facade_session_uses_private_load_owner_and_acknowledged_shutdown',
    'tests::workflow_run_execution_tests::native_serial_residency_tests::actual_post_load_pre_start_shutdown_signal_fences_guard_without_running_attempt',
    'tests::workflow_run_execution_tests::native_serial_residency_tests::actual_public_running_post_drain_cancellation_preserves_cap_and_exact_cleanup',
)
MAX_FILE = 8 * 1024 * 1024

class Unavailable(RuntimeError):
    pass

class CaseFailure(RuntimeError):
    def __init__(self, message, exit_code=1):
        super().__init__(message)
        self.exit_code = exit_code if isinstance(exit_code, int) and 0 < exit_code < 126 else 1


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_FILE, 'unsafe/oversize input: '+str(path))
    return json.loads(path.read_text())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def observed():
    return {'argv':[sys.executable,*sys.argv], 'cwd':str(Path.cwd()), 'python_sha256':sha(Path(sys.executable)),
            'resolved_python':str(Path(sys.executable).resolve()), 'sys_version':sys.version}


def admission():
    if not ADMISSION.is_file():
        raise Unavailable('Native execution is not admitted: external native-admission receipt is absent')
    receipt = read(ADMISSION)
    require(receipt.get('native_execution_admitted') is True and receipt.get('max_cases') == 3
            and receipt.get('retry_allowed') is False and receipt.get('authorization_reference'), 'native admission scope absent')
    require(receipt['final_manifest_sha256'] == sha(ROOT/'final-file-sha256.json'), 'native admission final freeze mismatch')
    require(receipt['launcher_sha256'] == sha(ROOT/'native_launcher.py')
            and receipt['supervisor_sha256'] == sha(ROOT/'owned_process.py')
            and receipt['commands_sha256'] == sha(ROOT/'commands.json'), 'native admission launcher mismatch')
    return receipt


def verify_inputs():
    receipt = admission()  # Before any native spawn or output-root mutation.
    start = time.monotonic()
    plan = read(ROOT/'launcher-plan.json')
    actual = observed()
    require(actual['argv'] == plan[sys.argv[1]] and actual['cwd'] == str(ROOT), 'actual Python/argv/cwd differs from frozen launch')
    runtime = read(ROOT/'python-runtime-freeze.json')
    require(actual['python_sha256'] == runtime['executable_sha256']
            and actual['resolved_python'] == runtime['resolved_executable']
            and actual['sys_version'] == runtime['sys_version'], 'Python runtime changed')
    for name, digest in read(ROOT/'final-file-sha256.json').items():
        path = ROOT/name
        require(path.resolve().is_relative_to(ROOT) and sha(path) == digest, 'protocol file changed: '+name)
        require(time.monotonic()-start <= 60, 'preflight observation elapsed')
    source = read(ROOT/'source-freeze.json')
    require(receipt['head'] == source['head'] and receipt['tree'] == source['tree'], 'admitted source changed')
    for args, expected in [(['rev-parse','HEAD'],source['head']),(['rev-parse','HEAD^{tree}'],source['tree']),(['status','--porcelain'],'')]:
        result = subprocess.check_output(['git',*args],cwd=REPO,text=True,timeout=10).strip()
        require(result == expected, 'source identity/clean state changed')
    for name, digest in source['files'].items():
        require(sha(REPO/name) == digest, 'source bytes changed: '+name)
    for name, digest in read(ROOT/'preservation-freeze.json').items():
        require(sha(Path(name)) == digest, 'historical evidence changed: '+name)
    for mode in ('inventory','default'):
        binary = read(ROOT/(mode+'-binary-reference.json'))
        path = Path(binary['binary'])
        require(binary['source_head'] == source['head'] and binary['source_tree'] == source['tree'], 'binary source mismatch')
        require(path.stat().st_mode & 0o777 == 0o500 and sha(path) == binary['sha256'], 'binary changed')
    fixture = read(ROOT/'fixture-contract.json')
    for name,digest in fixture['files'].items():
        require(sha(Path(fixture['root'])/name) == digest, 'fixture changed')
    runtime_ref = read(ROOT/'runtime-reference.json')
    require(sha(Path(runtime_ref['prlimit_path'])) == runtime_ref['prlimit_sha256'], 'prlimit changed')
    env = read(ROOT/'environment-freeze.json')
    require(sorted(os.sched_getaffinity(0)) == env['cpu_affinity'], 'affinity changed')
    for name,value in env['cgroup'].items():
        require((Path('/sys/fs/cgroup')/name).read_text().strip() == value, 'cgroup changed')
    for name,value in env['inherited_controls'].items():
        require(os.environ.get(name) == value, 'inherited control changed: '+name)
    commands = read(ROOT/'commands.json')
    require(tuple(case['test'] for case in commands['cases']) == TESTS and commands['case_order_is_serial'] is True, 'selected cases changed')
    require(commands['source_head'] == source['head'] and commands['source_tree'] == source['tree'], 'commands source changed')
    require(time.monotonic()-start <= 60, 'preflight observation elapsed')
    return commands


def group_rss(pgid, proc=Path('/proc')):
    total = 0
    count = 0
    for entry in proc.iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            fields = (entry/'stat').read_text().rsplit(')',1)[1].split()
            if int(fields[2]) != pgid or fields[0] in ('Z','X'):
                continue
            status = (entry/'status').read_text()
            rows = [line for line in status.splitlines() if line.startswith('VmRSS:')]
            if not rows and (entry/'stat').read_text().rsplit(')',1)[1].split()[0] in ('Z','X'):
                continue
            require(len(rows) == 1 and rows[0].split()[2] == 'kB', 'RSS observation unavailable')
            total += int(rows[0].split()[1])*1024
            count += 1
            require(count <= 4096, 'process-group observation size limit')
        except (FileNotFoundError, ProcessLookupError):
            continue
    return total


def output_bytes(directory):
    total = 0
    entries = 0
    for path in directory.rglob('*'):
        entries += 1
        require(entries <= 4096 and not path.is_symlink(), 'unsafe/oversize output tree')
        try:
            if path.is_file():
                total += path.stat().st_size
        except FileNotFoundError:
            pass  # TempDir normal cleanup can race observation.
    return total


def journal(path):
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= 4*1024*1024, 'facade progress absent/oversize')
    data = path.read_bytes()
    require(data.endswith(b'\n'), 'facade journal has incomplete final record')
    rows = [json.loads(line) for line in data.splitlines()]
    require(0 < len(rows) <= 8192 and [r['sequence'] for r in rows] == list(range(len(rows))), 'facade journal sequence mismatch')
    require(rows[0]['event'] == 'case_started' and rows[-1]['event'] == 'oracle_completed'
            and rows[-1]['data'] == {'ok':True}, 'facade complete journal absent')
    return rows


def validate_case(case, directory):
    log_path = directory/'test.log'
    require(log_path.stat().st_size <= MAX_FILE, 'log exceeds file bound')
    log = log_path.read_text()
    require(case['test'] in log and re.search(r'^test result: ok\. 1 passed; 0 failed; 0 ignored;',log,re.M), 'exact one-case result absent')
    name = case['test'].split('::')[-1]
    evidence = read(directory/'evidence'/(name+'.json'))
    require(evidence['case_id'] == name and evidence['oracle']['ok'] is True, 'source oracle evidence absent')
    if case['order'] == 1:
        require('diagnostic_io_error' in evidence and evidence['diagnostic_io_error'] is None and evidence['host_dependency_inventory'] is True, 'facade diagnostics incomplete')
        journal(directory/'evidence'/(name+'.progress.jsonl'))
    # Inner expected run/shutdown errors and honest fences are source-owned
    # negative oracle branches; never replace them with a blanket no-error rule.
    return {'case_id':name, 'evidence_sha256':sha(directory/'evidence'/(name+'.json')),
            'cleanup_disposition':evidence.get('cleanup_disposition'),
            'raw_readiness':'private snapshots unavailable; not synthesized'}


def suite_deadline(started, now):
    require(started <= now <= started+1380, 'suite observation already elapsed/clock changed')
    return started+1380


def execute_case(case, suite_deadline):
    directory = RUN/'cases'/f'{case["order"]:02d}'
    directory.mkdir()
    for name in ('tmp','evidence'):
        (directory/name).mkdir()
    env = os.environ.copy()
    env.update(case['env_set'])
    for name in case['env_unset']:
        env.pop(name,None)
    record = {'test':case['test'], 'argv':case['argv'], 'cwd':case['cwd'], 'started_utc':datetime.now(timezone.utc).isoformat(),
              'observer_seconds':420, 'retry_allowed':False, 'rss_samples':0, 'peak_sampled_group_rss_bytes':0, 'peak_sampled_output_bytes':0}
    write(directory/'claim.json',record)
    owner = None
    errors = []
    cleanup = None
    with (directory/'test.log').open('xb') as stream:
        try:
            started = time.monotonic()
            require(time.monotonic() <= suite_deadline, 'suite observer elapsed before native spawn')
            owner = OwnedChild(case['argv'],cwd=case['cwd'],env=env,stdout=stream)
            while not owner.done.is_set():
                require(time.monotonic()-started <= 420 and time.monotonic() <= suite_deadline, 'case/suite observer elapsed')
                rss = group_rss(owner.pgid)
                size = output_bytes(directory)
                record['rss_samples'] += 1
                record['peak_sampled_group_rss_bytes'] = max(record['peak_sampled_group_rss_bytes'],rss)
                record['peak_sampled_output_bytes'] = max(record['peak_sampled_output_bytes'],size)
                require(rss <= 2*1024**3, 'sampled process-group RSS limit exceeded')
                require(size <= 64*1024**2, 'sampled output-tree limit exceeded')
                owner.done.wait(timeout=0.02)
            require(time.monotonic()-started <= 420 and time.monotonic() <= suite_deadline, 'terminal case/suite observer elapsed')
        except BaseException as error:
            errors.append(f'{type(error).__name__}: {error}')
        finally:
            if owner is not None:
                cleanup = owner.finish_bounded(stop=bool(errors))
    try:
        terminal_size = output_bytes(directory)
        record['peak_sampled_output_bytes'] = max(record['peak_sampled_output_bytes'],terminal_size)
        require(terminal_size <= 64*1024**2, 'terminal output-tree limit exceeded')
    except BaseException as error:
        errors.append(f'{type(error).__name__}: {error}')
    record.update(errors=errors,supervision=cleanup,exit_code=owner.returncode if owner is not None else None)
    write(directory/'process-result.json',record)
    if (errors or not cleanup or not cleanup['process_reaped'] or not cleanup['cleanup_complete']
            or cleanup['supervisor_retained'] or cleanup['errors'] or cleanup['signals'] or owner.returncode != 0):
        raise CaseFailure('case failed/uncertain; raw logs and any partial progress preserved: '+case['test'],record['exit_code'])
    record['evidence'] = validate_case(case,directory)
    write(directory/'accepted-source-oracle.json',record['evidence'])
    require(output_bytes(directory) <= 64*1024**2, 'final output-tree limit exceeded')
    return record


def main():
    owned_root = False
    try:
        if sys.argv[1:] not in (['verify'],['execute']):
            raise Unavailable('Unsupported action: expected verify or execute only')
        admitted = admission()
        attempt_started = time.monotonic()
        if sys.argv[1] == 'verify':
            require(not RUN.exists(), 'reserved run root already exists')
            RUN.mkdir()
            owned_root = True
            commands = verify_inputs()
            write(RUN/'preflight.json',{'actual_launch':observed(),'head':commands['source_head'],'tree':commands['source_tree'],'native_cases_executed':0,'admission_sha256':sha(ADMISSION),'suite_started_monotonic':attempt_started})
            print('Native preflight verified under external admission; zero cases executed.')
            return 0
        require(RUN.is_dir() and not any((RUN/p).exists() for p in ('invocation-claim.json','cases','suite-result.json','stage-failure.json')), 'existing execution refuses reentry')
        preflight = read(RUN/'preflight.json')
        require(preflight['head'] == admitted['head'] and preflight['tree'] == admitted['tree']
                and preflight['admission_sha256'] == sha(ADMISSION), 'preflight ownership/admission mismatch')
        owned_root = True
        commands = verify_inputs()
        require(preflight['head'] == commands['source_head'] and preflight['tree'] == commands['source_tree']
                and preflight['admission_sha256'] == sha(ADMISSION), 'preflight source/admission mismatch')
        require(preflight['actual_launch']['argv'] == read(ROOT/'launcher-plan.json')['verify'], 'preflight launch changed')
        require(read(RUN/'preflight-outer-exit.json')['exit_code'] == 0, 'actual preflight outer0 missing')
        owned_root = True
        deadline = suite_deadline(preflight['suite_started_monotonic'],time.monotonic())
        write(RUN/'invocation-claim.json',{'actual_launch':observed(),'head':commands['source_head'],'tree':commands['source_tree'],'attempt':1,'retry_allowed':False})
        (RUN/'cases').mkdir()
        results = [execute_case(case,deadline) for case in commands['cases']]
        require(time.monotonic() <= deadline, 'suite observer elapsed')
        write(RUN/'suite-result.json',{'head':commands['source_head'],'tree':commands['source_tree'],'passed':3,'failed':0,'retry_allowed':False,'cases':results,
              'scope':'original three native regression assertions with durable facade progress; no cohort, performance, GPU, batching or hosted qualification'})
        return 0
    except BaseException as error:
        if owned_root:
            try:
                write(RUN/'stage-failure.json',{'kind':type(error).__name__,'error':str(error),'retry_allowed':False})
            except BaseException:
                pass
        print(f'Native action unavailable/failed: {type(error).__name__}: {error}',file=sys.stderr)
        return error.exit_code if isinstance(error,CaseFailure) else 2 if isinstance(error,Unavailable) else 1


if __name__ == '__main__':
    raise SystemExit(main())
