# C5 second bounded model-free validation

The distinct second attempt completed at exact source `47077561ed0ec31e4807b6b57e1a8fcdb5b76c10` (tree `cb8e08bf18d308c74500d2a86049b4e52264c721`): **nine model-free cases passed once, zero failed, zero native cases or model cohorts executed**. Formal preflight and the execution command both returned actual outer exit 0. Independent raw evidence review is recorded separately; this result does not establish native or hosted C5 acceptance.

## Identity and first-attempt disposition

- Identity: `m4-c5-model-free-v2-source470775-pythonusrbin-once`.
- Evidence root: `/workspace/m4-c5-repair-v2`; source worktree: `/workspace/pantograph-m4-c5`, branch `local/m4-c5-inventory-contract-2026-10-20`, clean.
- No source change was made in this second attempt. The existing five-commit repair remains exactly six paths relative to `e792fa61125d037d5d863e2aacab030fb6ca5c0c` (702 insertions / 66 deletions).
- The first attempt at `71325cac` remains **failed and protocol-inconformant**: one pass, one failure, seven unrun. Its unchanged-state oracle compared the registry collection timestamp, which changed between observations. Separately, its actual `/usr/bin/python3` invocation differed from the Python path frozen in that attempt's launch plan. Neither cause was retroactively excused or overwritten.
- The independently reviewed `47077561` correction records one complete typed registry snapshot per observation, retains raw collection timestamps, and removes only `registry.generated_at_ms` from comparison clones. Runtime/reservation state, runtime transition timestamps, scheduler/session/queue/ledger/native facts remain compared. The first handoff's uncompiled/untested status is historical; this separately authorized second attempt supplies the new compilation and nine-case evidence.

## Exact launch and compilation

The new contract explicitly uses `/usr/bin/python3`, resolving to `/usr/bin/python3.13`, version `3.13.5 (main, Jul 15 2026, 20:25:40) [GCC 14.2.0]`, executable SHA256 `17b78e0a93175e86f9ac03141924fd7a7f0c0c52e66b34bfa0de20ffef989df1`. The runner checks exact `sys.executable`, full argv, working directory, resolved executable, executable hash and version before it can launch a case. Actual preflight and execution witnesses match the frozen commands. The unchanged process supervisor has SHA256 `3e7b95f9b12fee0ee9dc8a02805172d08a20b599bac669fe576ba21fc1d3251b`.

| Action | Actual outcome | Test cases executed |
| --- | --- | --- |
| Default `cargo test --locked --offline --lib --no-run` | Exit 0, exact-source binary compiled | 0 |
| Inventory-feature `cargo test --locked --offline --lib --no-run` | Exit 0, exact-source binary compiled | 0 |
| Default and inventory `--list` discovery | Each selected case exactly once; native three absent default / present inventory | 0 |
| Frozen formal preflight, once | Outer exit 0, actual Python witness matches | 0 |
| Frozen model-free execution, once | Outer exit 0; all nine exact cases passed | 9 |

The binaries are frozen independently of Cargo's mutable target directory, mode 0500:

- Default: `binaries/default-tests-47077561`, 207,846,536 bytes, SHA256 `48da9044bf85766179aaa75710ae37eba3144bd9e0e31d0331ecbe2fe41c71cf`.
- Inventory: `binaries/inventory-tests-47077561`, 208,734,512 bytes, SHA256 `dd579b84f3ef27a88edf20f1d7f3b55f6fa513985b25d3be2b8a94117971d949`.

Build JSON, stderr logs and actual terminal-session records are retained. Source formatting and whitespace checks passed; no new Clippy or broader test suite ran in this attempt. The earlier traceability command's missing `commonmark` dependency remains a preserved tooling limitation; no environment or dependency installation was performed.

## Executed cases and bounded evidence

Every row ran in its own serial process, exact filter, one test thread, isolated registry database, offline model controls and ten-second observation bound. Every child returned 0 and was reaped with complete process cleanup, no signals/errors and no retained supervisor. Nine case logs and nine case JSON witnesses are retained. No stage-failure marker exists, and no automatic repair or rerun occurred.

| Feature mode | Exact test suffix | Observed result |
| --- | --- | --- |
| Default | `default_native_inventory_is_not_implemented` | Actual two-binding provider Check NotImplemented; actual scheduler projection TerminalFailed/Fail |
| Default | `default_run_requires_inventory_before_enqueue` | Exact prerequisite rejection; unchanged stable facts; native boundary assertions; close/shutdown completed |
| Default | `default_resume_requires_inventory_before_enqueue` | Same bounded early-entry rejection and cleanup; no otherwise-resumable paused run claimed |
| Default | `closed_admission_precedes_missing_inventory` | Existing closed-admission error precedes missing-inventory check for run and resume; shutdown completed |
| Default | `projection_refresh_publishes_existing_raw_evidence_without_native_work` | Existing projection evidence remains available; zero native work |
| Default | `metadata_sessions_never_load_reserve_or_mint_physical_load_proof` | Existing metadata support remains available; no physical load/reservation proof minted |
| Inventory | `hosted_inventory_without_explicit_owner_context_stays_conservative` | Actual two-binding provider Check NotImplemented; actual scheduler projection TerminalFailed/Fail |
| Inventory | `hosted_inventory_observes_real_compiled_candle_lifecycle` | Actual two-binding compiled capability Check Ready; scheduler projection Ready; metadata only |
| Inventory | `hosted_inventory_preserves_unsupported_candle_feature` | Unsupported external_connection remains Unavailable; scheduler projection intentionally null |

The negative run/resume raw snapshots retain collection times while stable comparisons preserve every other field. Their queues and ledgers are empty, native counters zero, reservations empty, and no runtime instance/model ownership is created. Passing the test also reaches both nonblocking native-boundary assertions and explicit close/shutdown, which the failed first attempt did not reach.

Actual provider Check results, binding rows, payloads, provenance and projections are included. The underlying private raw inventory ProbeNotImplemented response remains source-correlated rather than separately serialized. Controlled component evidence does not prove the first error of earlier hosted jobs.

An auxiliary read-only post-run display script failed on the intentionally null `scheduler_decision` in the unsupported-feature case. It had already checked all nine actual child exits and did not modify protocol inputs/results. Its initial record and precise clarification are preserved as `postprocess-reader-failure.json` and `postprocess-reader-clarification.json`. This reporting error caused no test or protocol retry and does not replace the raw case evidence.

## Preservation and remaining admission

All 28 final frozen inputs and all 1,123 prior preservation entries matched after execution. This includes completed C4, the unchanged `e792fa61` handoff, the first attempt's full 75-file evidence set, all four earlier frozen executables and its archive/record. The first attempt's 63-file failed-stage manifest remains unchanged. Source, completed C4 and the handoff candidate remain clean at their original heads. There was no external publication, PR edit, merge, deletion, model or environment change.

The second attempt's `post-execution-file-sha256.json` freezes 100 input/output files before subsequent read-only clarification/review/handoff artifacts. `source-recovery.bundle` is an exact copy of the preserved recovery bundle, SHA256 `03e17bec405ab780c77d098d1397be8454f4d7fd621376974a8b47c4b4d6edc9`, requiring base `e792fa61` and recovering current source `47077561`.

The three native cases were **discovered only**. Native diagnostic and explicit CI-discovery preparation remain source-reviewed, with raw private native readiness explicitly unavailable. Native Stage B, any model cohort, new hosted exact-head CI, publication and broader C5 acceptance require separate coordination/admission. No speedup, GPU, native batching, native execution or production qualification is claimed. The archive excludes the two immutable test executables and Python bytecode; executables remain locally retained with exact hashes/build manifests.
