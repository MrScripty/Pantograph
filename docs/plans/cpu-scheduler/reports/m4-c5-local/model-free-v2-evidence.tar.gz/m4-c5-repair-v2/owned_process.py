"""Linux owned-child containment. File observers never own process completion.

The non-daemon supervisor is the sole waiter. It keeps the leader unreaped with
waitid(WNOWAIT) until group containment is decided, avoiding PGID reuse while
signalling. A deadline bounds the caller's cleanup observation, not OS reap.
If the kernel cannot finish, the supervisor stays alive with the handle.
"""
import errno
import os
from pathlib import Path
import signal
import subprocess
import threading
import time

TERM_GRACE_SECONDS = 1.0
KILL_GRACE_SECONDS = 2.0
POLL_SECONDS = 0.02


class OwnedChild:
    def __init__(self, argv, *, cwd, env, stdout, term_grace=TERM_GRACE_SECONDS,
                 kill_grace=KILL_GRACE_SECONDS):
        self.term_grace = term_grace
        self.kill_grace = kill_grace
        self.stop = threading.Event()
        self.done = threading.Event()
        self.cleanup_incomplete = threading.Event()
        self.errors = []
        self.error_count = 0
        self.signals = []
        self.reaped = False
        self.returncode = None
        self.child = None
        self.thread = None
        self.stop_at = None
        self.kill_sent = False
        # No file write or callback is allowed between successful spawn and this
        # owner's protected adoption. A thread-start failure drains synchronously.
        self.child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout,
                                      stderr=subprocess.STDOUT, start_new_session=True)
        self.pid = self.child.pid
        self.pgid = self.pid
        try:
            self.thread = threading.Thread(target=self._supervise,
                                           name=f'owned-child-{self.pid}', daemon=False)
            self.thread.start()
        except BaseException as error:
            self._error('supervisor_start', error)
            self.stop.set()
            self._supervise()

    def _error(self, operation, error):
        self.error_count += 1
        if len(self.errors) < 20:
            self.errors.append(f'{operation}: {type(error).__name__}: {error}')

    def _live_group(self):
        live = []
        for entry in Path('/proc').iterdir():
            if not entry.name.isdecimal():
                continue
            try:
                fields = (entry/'stat').read_text().rsplit(')', 1)[1].split()
                if int(fields[2]) == self.pgid and fields[0] not in ('Z', 'X'):
                    live.append(int(entry.name))
            except (FileNotFoundError, ProcessLookupError):
                pass
        return live

    def _signal_group(self, number):
        try:
            os.killpg(self.pgid, number)
            self.signals.append(number)
        except OSError as error:
            if error.errno != errno.ESRCH:
                self._error('signal_group', error)

    def _observe_exit(self):
        return os.waitid(os.P_PID, self.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT) is not None

    def _reap(self):
        try:
            self.returncode = self.child.wait(timeout=0)
        except BaseException as error:
            self._error('popen_wait', error)
            # Popen may have completed bookkeeping before an interruption.
            if self.child.returncode is not None:
                self.returncode = self.child.returncode
            else:
                pid, status = os.waitpid(self.pid, os.WNOHANG)
                if pid == 0:
                    return False
                self.returncode = os.waitstatus_to_exitcode(status)
                self.child.returncode = self.returncode
        self.reaped = True
        return True

    def _tick(self):
        try:
            exited = self._observe_exit()
        except BaseException as error:
            self._error('observe_exit', error)
            self.stop.set()
            exited = False
        live = None
        if not self.stop.is_set():
            try:
                live = self._live_group()
            except BaseException as error:
                self._error('scan_group', error)
                self.stop.set()
            if exited and live:
                self._error('descendant_lifetime', RuntimeError('live group remains after leader exit'))
                self.stop.set()
        if self.stop.is_set():
            moment = time.monotonic()
            if self.stop_at is None:
                self.stop_at = moment
                self._signal_group(signal.SIGTERM)
            if moment >= self.stop_at + self.term_grace and not self.kill_sent:
                self._signal_group(signal.SIGKILL)
                self.kill_sent = True
            if moment >= self.stop_at + self.term_grace + self.kill_grace:
                self.cleanup_incomplete.set()
            # Reinspect after signals; never reap the leader while live group
            # members could survive and before a subsequent signal is needed.
            try:
                live = self._live_group()
            except BaseException as error:
                self._error('scan_group', error)
                # Inspection failure cannot block signals or claim an empty
                # group. Keep this owner alive until observation/reap resolves.
                return False
            if not live and self._reap():
                return True
        elif exited and not live and self._reap():
            return True
        return False

    def _supervise(self):
        while True:
            try:
                if self._tick():
                    self.done.set()
                    return
            except BaseException as error:
                self._error('supervisor', error)
                self.stop.set()
            # This owner must not unwind with a live/unreaped child, even after
            # deadline or repeated OS errors. No native cleanup is inferred.
            time.sleep(POLL_SECONDS)

    def wait(self):
        self.done.wait()
        return self.returncode

    def finish_bounded(self, stop=False):
        if stop:
            self.stop.set()
        deadline = time.monotonic() + self.term_grace + self.kill_grace + 0.25
        while not self.done.is_set() and time.monotonic() < deadline:
            try:
                self.done.wait(timeout=POLL_SECONDS)
            except BaseException as error:
                self._error('cleanup_observer', error)
                self.stop.set()
        complete = self.done.is_set()
        if complete and self.thread is not None and self.thread.ident is not None:
            self.thread.join()
        return {'process_reaped': self.reaped, 'child_exit_code': self.returncode,
                'cleanup_complete': complete, 'supervisor_retained': not complete,
                'supervisor_non_daemon': self.thread is None or not self.thread.daemon,
                'pid': self.pid, 'pgid': self.pgid, 'signals': list(self.signals),
                'errors': list(self.errors), 'error_count': self.error_count,
                'descendants_reaped': 'not claimed; group containment checks live /proc states',
                'native_cleanup_proof': 'not provided by process containment'}
