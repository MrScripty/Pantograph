"""Execute exactly the reviewed nine model-free cases, once, with owned processes."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import subprocess
from datetime import datetime, timezone
from owned_process import OwnedChild

ROOT = Path('/workspace/m4-c5-repair-v2')
REPO = Path('/workspace/pantograph-m4-c5')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def now():
    return datetime.now(timezone.utc).isoformat()


def observed_launch():
    return {'executable':sys.executable, 'resolved_executable':str(Path(sys.executable).resolve()),
            'executable_sha256':sha(Path(sys.executable)), 'sys_version':sys.version,
            'argv':[sys.executable,*sys.argv], 'cwd':str(Path.cwd())}


def verify():
    require(not any((ROOT/p).exists() for p in ('invocation-claim.json','cases','evidence','suite-result.json','stage-failure.json')), 'existing execution refuses reentry')
    for name, digest in read(ROOT/'pre-run-file-sha256.json').items():
        path = ROOT/name
        require(path.resolve().is_relative_to(ROOT.resolve()) and sha(path) == digest, 'frozen input changed: '+name)
    launch = read(ROOT/'launch-plan.json')
    runtime = read(ROOT/'python-runtime-freeze.json')
    require([sys.executable, *sys.argv] == launch[sys.argv[1]], 'actual Python path/argv differs from frozen launch command')
    require(Path.cwd() == ROOT, 'launcher working directory differs from frozen plan')
    require(str(Path(sys.executable).resolve()) == runtime['resolved_executable'], 'Python resolution changed')
    require(sha(Path(sys.executable)) == runtime['executable_sha256'], 'Python executable changed')
    require(sys.version == runtime['sys_version'], 'Python version changed')
    plan = read(ROOT/'case-plan.json')
    require(len(plan['cases']) == 9 and plan['native_cases_to_execute'] == 0 and plan['retry_allowed'] is False, 'case scope changed')
    require(len({c['test'] for c in plan['cases']}) == 9, 'duplicate test')
    require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip() == plan['head'], 'source changed')
    require(subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO,text=True).strip() == plan['tree'], 'source tree changed')
    require(not subprocess.check_output(['git','status','--porcelain'],cwd=REPO), 'dirty source')
    for name,digest in read(ROOT/'source-freeze.json')['files'].items():
        require(sha(REPO/name) == digest,'source bytes changed: '+name)
    for mode in ('default','inventory'):
        binary=read(ROOT/plan['binaries'][mode])
        require(sha(Path(binary['binary'])) == binary['sha256'], 'binary changed')
        require(Path(binary['binary']).stat().st_mode & 0o777 == 0o500, 'binary mode changed')
    for name,digest in read(ROOT/'preservation-freeze.json').items():
        require(sha(Path(name)) == digest,'preserved evidence changed: '+name)
    env=read(ROOT/'environment-freeze.json')
    require(sorted(os.sched_getaffinity(0)) == env['cpu_affinity'],'affinity changed')
    for name,value in env['cgroup'].items():
        path=Path('/sys/fs/cgroup')/name
        require((path.read_text().strip() if path.exists() else None) == value,'cgroup changed')
    for name,value in env['inherited_controls'].items():
        require(os.environ.get(name) == value,'inherited control changed: '+name)
    receipt=read(ROOT/'independent-pretest-admission.json')
    require(receipt['approved'] is True and receipt['head'] == plan['head'] and receipt['tree'] == plan['tree'], 'independent admission absent/stale')
    require(receipt['input_manifest_sha256'] == sha(ROOT/'input-file-sha256.json'), 'reviewed inputs changed')
    require(receipt['runner_sha256'] == sha(ROOT/'run_model_free.py') and receipt['supervisor_sha256'] == sha(ROOT/'owned_process.py'), 'launcher review stale')
    return plan


def execute():
    plan=verify()
    require(read(ROOT/'preflight-outer-exit.json')['exit_code'] == 0, 'actual formal preflight outer exit absent/nonzero')
    preflight = read(ROOT/'preflight-launch-observed.json')
    require(preflight['argv'] == read(ROOT/'launch-plan.json')['verify'], 'formal preflight actual launch mismatch')
    require(preflight['executable_sha256'] == sha(Path(sys.executable)), 'formal preflight interpreter changed')
    write(ROOT/'invocation-claim.json',{'head':plan['head'],'tree':plan['tree'],'started_utc':now(),'attempt':1,'retry_allowed':False,'native_cases':0,'actual_launch':observed_launch()})
    (ROOT/'cases').mkdir()
    (ROOT/'evidence').mkdir()
    results=[]
    for index,case in enumerate(plan['cases']):
        directory=ROOT/'cases'/f'{index+1:02d}-{case["test"].split("::")[-1]}'
        directory.mkdir()
        binary=read(ROOT/plan['binaries'][case['mode']])
        argv=[binary['binary'],case['test'],'--exact','--test-threads=1','--nocapture']
        env=os.environ.copy()
        env.update({'ORT_SKIP_DOWNLOAD':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','TOKENIZERS_PARALLELISM':'false',
                    'PUMAS_REGISTRY_DB_PATH':str(directory/'registry.db'),
                    'PANTOGRAPH_M4_C5_MODEL_FREE_EVIDENCE_ROOT':str(ROOT/'evidence')})
        env.pop('PANTOGRAPH_M4_CANCELLATION_EVIDENCE_ROOT',None)
        env.pop('PANTOGRAPH_CPU_EMBEDDING_FIXTURE_ROOT',None)
        record={'test':case['test'],'mode':case['mode'],'argv':argv,'binary_sha256':binary['sha256'],'started_utc':now(),'observer_seconds':10}
        write(directory/'claim.json',record|{'attempt':1,'retry_allowed':False})
        owner=None
        errors=[]
        complete=False
        cleanup=None
        with (directory/'test.log').open('xb') as stream:
            try:
                owner=OwnedChild(argv,cwd=REPO,env=env,stdout=stream)
                complete=owner.done.wait(timeout=10)
                if not complete:
                    errors.append('ten-second case observation elapsed')
            except BaseException as error:
                errors.append(f'{type(error).__name__}: {error}')
            finally:
                if owner is not None:
                    cleanup=owner.finish_bounded(stop=bool(errors) or not complete)
        record.update(completed_utc=now(),errors=errors,supervision=cleanup)
        if owner is not None:
            record['exit_code']=owner.returncode
        write(directory/'process-result.json',record)
        require(not errors and cleanup and cleanup['process_reaped'] and cleanup['cleanup_complete'] and not cleanup['supervisor_retained']
                and not cleanup['errors'] and not cleanup['signals'] and owner.returncode == 0, 'case process failed: '+case['test'])
        log=(directory/'test.log').read_text()
        require(len(log.encode()) < 1024*1024 and re.search(r'^test result: ok\. 1 passed; 0 failed; 0 ignored;',log,re.M), 'exact test result absent')
        require(case['test'] in log,'wrong test observed')
        evidence=read(ROOT/'evidence'/(case['test'].split('::')[-1]+'.json'))
        require(evidence['case'] == case['test'].split('::')[-1] and evidence['host_dependency_inventory'] is (case['mode']=='inventory'), 'wrong compiled feature/case witness')
        results.append(record)
    require(len(list((ROOT/'evidence').glob('*.json'))) == 9,'unexpected evidence count')
    write(ROOT/'suite-result.json',{'head':plan['head'],'tree':plan['tree'],'passed':9,'failed':0,'native_cases_executed':0,'retry_allowed':False,'cases':results})
    return 0


def main():
    try:
        require(sys.argv[1:] in (['verify'],['execute']),'expected verify or execute')
        if sys.argv[1]=='verify':
            verify()
            write(ROOT/'preflight-launch-observed.json',observed_launch())
            print('Frozen nine-case model-free preflight passed; no tests executed.')
            return 0
        return execute()
    except BaseException as error:
        try:
            write(ROOT/'stage-failure.json',{'error':f'{type(error).__name__}: {error}','time_utc':now(),'retry_allowed':False,'native_cases_executed':0})
        except BaseException:
            pass
        print(f'Model-free stage stopped: {type(error).__name__}: {error}',file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
