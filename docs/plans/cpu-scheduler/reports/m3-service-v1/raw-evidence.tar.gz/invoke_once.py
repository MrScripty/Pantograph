import datetime, hashlib, json, os, pathlib, platform, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/workspace/pantograph-m3')
binary=pathlib.Path('/workspace/pantograph-cache/target/release/examples/cpu_embedding_workflow_probe')
def git(*args):
 return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def digest(p):
 return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, data):
 (root/name).write_text(json.dumps(data,indent=2)+'\n')
def now():
 return datetime.datetime.now(datetime.timezone.utc).isoformat()
expected='e9d89eacf686b163539c08ebc6225a6c2750bc96'
if git('rev-parse','HEAD')!=expected or git('status','--porcelain'):
 raise SystemExit('source freeze mismatch/dirty worktree; no execution')
if not binary.is_file():
 raise SystemExit('release binary unavailable; no execution')
with (root/'invocation.started').open('x') as marker:
 marker.write(now()+'\n')
env=os.environ.copy()
env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', ORT_SKIP_DOWNLOAD='1',
 OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
 PUMAS_REGISTRY_DB_PATH=str(root/'run/registry.db'))
paths=git('diff','--name-only','4aec0d5c4927a6af2832d40e224be5c2136fc9ef...HEAD').splitlines()
manifest={'protocol':'m3-authenticated-service-v1','source_commit':expected,
 'source_tree':git('rev-parse','HEAD^{tree}'),'worktree_status':git('status','--porcelain'),
 'base':'4aec0d5c4927a6af2832d40e224be5c2136fc9ef',
 'binary_path':str(binary),'binary_sha256':digest(binary),
 'build_command':'cargo build --release --locked -p pantograph-embedded-runtime --example cpu_embedding_workflow_probe --no-default-features --features backend-candle,host-dependency-inventory',
 'changed_file_sha256':{p:digest(repo/p) for p in paths},
 'fixture_manifest_sha256':digest(repo/'crates/inference/tests/fixtures/candle_bert/reference-manifest.json'),
 'rustc':subprocess.check_output(['rustc','-Vv'],text=True),
 'cargo':subprocess.check_output(['cargo','-V'],text=True).strip(),
 'platform':platform.platform(),'cpu_max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
 'memory_max':pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip(),
 'logical_cpus':os.cpu_count(),
 'gpu_interfaces':{p:pathlib.Path(p).exists() for p in ['/dev/nvidia0','/dev/nvidiactl','/dev/dri','/dev/kfd','/proc/driver/nvidia','/sys/class/drm']},
 'selected_environment':{key:env[key] for key in ['HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','ORT_SKIP_DOWNLOAD','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','PUMAS_REGISTRY_DB_PATH']},
 'started_utc':now(),'planned_reference_invocations':1,'planned_native_cohort_invocations':1,
 'performance_claim':False,'new_model_acquisition':False,'controls':'transparent arrival and post-drain cancellation barriers'}
save('source-manifest.json',manifest)
reference=['/workspace/Pantograph/.venv/bin/python',str(repo/'crates/pantograph-embedded-runtime/examples/cpu_embedding_workflow_probe/c3_reference.py'),str(root/'reference.json')]
with (root/'reference.started').open('x') as marker:marker.write(now()+'\n')
with (root/'reference.stdout.log').open('w') as out,(root/'reference.stderr.log').open('w') as err:
 result=subprocess.run(reference,cwd=repo,env=env,stdout=out,stderr=err)
save('reference-status.json',{'command':reference,'exit_code':result.returncode,'finished_utc':now()})
if result.returncode:raise SystemExit(result.returncode)
if digest(binary)!=manifest['binary_sha256'] or git('rev-parse','HEAD')!=expected or git('status','--porcelain'):
 raise SystemExit('freeze changed after numerical reference; no native execution')
command=[str(binary),str(root/'run'),'--fair-service']
with (root/'native.started').open('x') as marker:marker.write(now()+'\n')
with (root/'native.stdout.log').open('w') as out,(root/'native.stderr.log').open('w') as err:
 result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
save('invocation-status.json',{'command':command,'exit_code':result.returncode,'finished_utc':now(),'binary_unchanged':digest(binary)==manifest['binary_sha256'],'source_unchanged':git('rev-parse','HEAD')==expected and not git('status','--porcelain'),'retry_performed':False})
print(json.dumps({'source':expected,'native_exit':result.returncode,'evidence':str(root)}))
raise SystemExit(result.returncode)
