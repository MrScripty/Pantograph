"""Freeze and supervise exactly one explicitly admitted native comparison."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

TEST = 'serial_cpu_residency::tests::key_reuse_qualification::held::fixed_two_ready_native_key_reuse_comparison'
PROTOCOL = 'docs/plans/cpu-scheduler/reports/2026-10-21-m5-native-key-reuse-protocol.md'
ADDRESS_SPACE = 8 * 1024 ** 3
WALL_SECONDS = 180


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    with Path(path).open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def write_new(path, value):
    with Path(path).open('x') as file:
        json.dump(value, file, indent=2)
        file.write('\n')
        file.flush()
        os.fsync(file.fileno())


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True, stderr=subprocess.PIPE).strip()


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (ADDRESS_SPACE, ADDRESS_SPACE))


def child_environment(root):
    # No GitHub or other account credentials are passed to the test process.
    selected = {key: os.environ[key] for key in
                ['PATH', 'HOME', 'LANG', 'LC_ALL', 'LD_LIBRARY_PATH', 'SSL_CERT_FILE', 'SSL_CERT_DIR', 'TMPDIR']
                if key in os.environ}
    selected.update({'PANTOGRAPH_M5_KEY_REUSE_EVIDENCE_ROOT': str(root),
                     'PUMAS_REGISTRY_DB_PATH': str(root / 'metadata.db'),
                     'TOKENIZERS_PARALLELISM': 'false', 'RAYON_NUM_THREADS': '1',
                     'OMP_NUM_THREADS': '1', 'RUST_BACKTRACE': '1'})
    return selected


def freeze(args):
    repo = Path(args.repo).resolve()
    root = Path(args.root).resolve()
    binary = Path(args.binary).resolve()
    assert not git(repo, 'status', '--porcelain=v1'), 'source must be clean before freeze'
    assert git(repo, 'rev-parse', 'HEAD') == args.head, 'source head moved'
    root.mkdir()  # No overwrite or continuation of an old experiment.
    shutil.copy2(binary, root / 'producer')
    shutil.copy2(repo / PROTOCOL, root / 'prospective-protocol.md')
    shutil.copy2(Path(__file__), root / 'supervisor.py')
    env = child_environment(root)
    fixture = repo / 'crates/inference/tests/fixtures/candle_bert/bert-8'
    fixtures = {str(p.relative_to(repo)): {'sha256': sha(p), 'bytes': p.stat().st_size}
                for p in sorted(fixture.rglob('*')) if p.is_file()}
    for name in ['reference-manifest.json', 'README.md']:
        p = fixture.parent / name
        fixtures[str(p.relative_to(repo))] = {'sha256': sha(p), 'bytes': p.stat().st_size}
    # Discovery is not an execution of the held test and initializes no facade.
    listed = subprocess.run([str(root / 'producer'), TEST, '--exact', '--ignored', '--list'],
                            cwd=repo, env=env, preexec_fn=limits, start_new_session=True,
                            text=True, capture_output=True, timeout=20)
    (root / 'discovery.stdout').write_text(listed.stdout)
    (root / 'discovery.stderr').write_text(listed.stderr)
    assert listed.returncode == 0 and listed.stdout.splitlines().count(TEST + ': test') == 1
    assert not (root / 'metadata.db').exists(), 'discovery performed unexpected metadata startup'
    def read(path):
        p = Path(path)
        return p.read_text().strip() if p.exists() else None
    manifest = {
        'frozen_utc': utc(), 'state': 'frozen_not_executed', 'protocol_id': 'm5-native-two-ready-key-reuse-v1',
        'source': {'repo': str(repo), 'head': args.head, 'tree': git(repo, 'rev-parse', 'HEAD^{tree}'),
                   'status': '', 'protocol_path': PROTOCOL, 'protocol_sha256': sha(repo / PROTOCOL)},
        'producer': {'original_path': str(binary), 'copied_path': str(root / 'producer'),
                     'sha256': sha(root / 'producer'), 'bytes': binary.stat().st_size},
        'supervisor_sha256': sha(root / 'supervisor.py'), 'fixtures': fixtures,
        'test': TEST, 'argv': [str(root / 'producer'), TEST, '--exact', '--ignored', '--nocapture', '--test-threads=1'],
        'environment': env,
        'platform': {'uname': list(os.uname()), 'affinity': sorted(os.sched_getaffinity(0)),
                     'cpu_max': read('/sys/fs/cgroup/cpu.max'), 'memory_max': read('/sys/fs/cgroup/memory.max'),
                     'model_names': sorted(set(line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')))},
        'resource_bounds': {'address_space_bytes': ADDRESS_SPACE, 'execution_wall_seconds': WALL_SECONDS,
                            'kill_reap_seconds': 5, 'native_forwards_total': 4, 'cpu_threads': 1,
                            'log_rows': 2048, 'log_bytes': 4 * 1024 * 1024},
        'outcome_criteria': {'baseline_encodings_hits': [6, 0], 'enabled_encodings_hits': [4, 4],
                             'healthy_retained_entries': 0, 'golden_absolute_tolerance': 1e-5,
                             'members_per_arm': 2, 'required_phases': ['probe', 'capture', 'fill', 'lookup', 'key_calculation'],
                             'owner_and_identity_joins': 'exact source oracle; registry ACK distinct from source-assisted scheduler matching',
                             'speedup_claim': False, 'complete_memory_claim': False, 'representative_model_or_hardware_claim': False},
        'toolchain': {'rustc': subprocess.check_output(['rustc', '--version'], text=True).strip(),
                      'cargo': subprocess.check_output(['cargo', '--version'], text=True).strip()},
        'admission': 'Independent exact-source/oracle/protocol and this manifest review required before run mode',
    }
    write_new(root / 'frozen-manifest.json', manifest)
    print(json.dumps({'root': str(root), 'manifest_sha256': sha(root / 'frozen-manifest.json'),
                      'head': args.head, 'tree': manifest['source']['tree'], 'producer_sha256': manifest['producer']['sha256']}))


def execute(args):
    root = Path(args.root).resolve()
    manifest_path = root / 'frozen-manifest.json'
    assert sha(manifest_path) == args.manifest_sha256, 'reviewed manifest changed'
    manifest = json.loads(manifest_path.read_text())
    repo = Path(manifest['source']['repo'])
    assert git(repo, 'rev-parse', 'HEAD') == manifest['source']['head']
    assert git(repo, 'rev-parse', 'HEAD^{tree}') == manifest['source']['tree']
    assert not git(repo, 'status', '--porcelain=v1')
    assert sha(repo / PROTOCOL) == manifest['source']['protocol_sha256']
    assert sha(root / 'prospective-protocol.md') == manifest['source']['protocol_sha256']
    assert sha(root / 'producer') == manifest['producer']['sha256']
    assert sha(Path(__file__)) == manifest['supervisor_sha256']
    assert sorted(os.sched_getaffinity(0)) == manifest['platform']['affinity']
    for name in ['cpu', 'memory']:
        path = Path(f'/sys/fs/cgroup/{name}.max')
        current = path.read_text().strip() if path.exists() else None
        assert current == manifest['platform'][name + '_max'], 'execution cgroup changed'
    for rel, info in manifest['fixtures'].items():
        assert sha(repo / rel) == info['sha256'], rel
    assert not (root / 'metadata.db').exists()
    # Exclusive marker is written before launch. No retry is built into this tool.
    write_new(root / 'execution-started.json', {'started_utc': utc(), 'manifest_sha256': args.manifest_sha256})
    result = {'started_utc': utc(), 'manifest_sha256': args.manifest_sha256,
              'timed_out': False, 'reaped': False, 'error': None,
              'acknowledged_cleanup': 'only actual producer evidence can establish this'}
    started = time.monotonic_ns()
    child = None
    try:
        with (root / 'producer.stdout.log').open('xb') as output:
            child = subprocess.Popen(manifest['argv'], cwd=repo, env=manifest['environment'],
                                     stdout=output, stderr=subprocess.STDOUT,
                                     preexec_fn=limits, start_new_session=True)
            result['pid'] = child.pid
            try:
                result['exit_code'] = child.wait(timeout=WALL_SECONDS)
                result['reaped'] = True
            except subprocess.TimeoutExpired:
                result['timed_out'] = True
                # This group belongs only to our start_new_session test process.
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                try:
                    result['exit_code'] = child.wait(timeout=5)
                    result['reaped'] = True
                except subprocess.TimeoutExpired:
                    result['error'] = 'owned process termination/reaping remains uncertain'
    except Exception as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    result['ended_utc'] = utc()
    result['supervised_elapsed_ns'] = time.monotonic_ns() - started
    comparison = root / 'comparison.json'
    if comparison.exists():
        try:
            value = json.loads(comparison.read_text())
            result['producer_oracle_ok'] = value.get('ok')
            result['producer_error'] = value.get('error')
        except (ValueError, OSError) as error:
            result['error'] = type(error).__name__ + ': ' + str(error)
    result['ok'] = (result.get('exit_code') == 0 and result['reaped'] and not result['timed_out']
                    and result['error'] is None and result.get('producer_oracle_ok') is True)
    result['interpretation'] = 'producer result; independent frozen-criterion evidence review still required'
    write_new(root / 'execution-result.json', result)
    print(json.dumps(result))
    return 0 if result['ok'] else 1


parser = argparse.ArgumentParser(description=__doc__)
sub = parser.add_subparsers(dest='operation', required=True)
frozen = sub.add_parser('freeze')
for option in ['repo', 'root', 'binary', 'head']:
    frozen.add_argument('--' + option, required=True)
running = sub.add_parser('run')
running.add_argument('--root', required=True)
running.add_argument('--manifest-sha256', required=True)
args = parser.parse_args()
if args.operation == 'freeze':
    freeze(args)
else:
    sys.exit(execute(args))
