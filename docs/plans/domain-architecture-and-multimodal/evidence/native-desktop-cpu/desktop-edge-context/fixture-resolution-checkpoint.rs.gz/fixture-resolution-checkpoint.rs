use pantograph_workflow_service::graph::{
    inference_interface_resolution_inputs_from_graph, InferenceInterfaceGraphResolutionDiagnosticCode,
    WorkflowGraph,
};

#[test]
fn native_fixture_context_reproduces_missing_context_and_resolves_corrected_request() {
    let old_graph: WorkflowGraph = serde_json::from_str(
        &std::fs::read_to_string(std::env::var("NATIVE_FIXTURE_OLD_GRAPH").unwrap()).unwrap(),
    )
    .unwrap();
    let old = inference_interface_resolution_inputs_from_graph(&old_graph);
    assert!(old.requests.is_empty());
    assert_eq!(old.diagnostics.len(), 1);
    assert_eq!(old.diagnostics[0].code, InferenceInterfaceGraphResolutionDiagnosticCode::MissingRuntimeSourceContext);
    let corrected_graph: WorkflowGraph = serde_json::from_str(
        &std::fs::read_to_string(std::env::var("NATIVE_FIXTURE_NEW_GRAPH").unwrap()).unwrap(),
    )
    .unwrap();
    let corrected = inference_interface_resolution_inputs_from_graph(&corrected_graph);
    assert!(corrected.diagnostics.is_empty(), "{:?}", corrected.diagnostics);
    assert_eq!(corrected.requests.len(), 1);
    let request = &corrected.requests[0];
    assert_eq!(request.node_id, "infer");
    assert_eq!(request.runtime_source_context.operation_type, "embedding.text");
    assert_eq!(request.runtime_source_context.context_shape_key, "embedding.one-text");
    assert_eq!(request.request.model_ref.model_id, "embedding/qualification/synthetic-bert-8");
}
