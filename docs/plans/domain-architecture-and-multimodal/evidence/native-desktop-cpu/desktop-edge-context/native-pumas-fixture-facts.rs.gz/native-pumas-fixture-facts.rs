#[tokio::test]
async fn inspect_real_pumas_owner_facts_for_native_fixture() {
    let root = std::env::var("NATIVE_PUMAS_FIXTURE_ROOT").unwrap();
    let api = pumas_library::PumasApi::builder(&root)
        .with_hf_client(false)
        .with_process_manager(false)
        .build()
        .await
        .unwrap();
    let facts = api
        .resolve_model_package_facts("embedding/qualification/synthetic-bert-8")
        .await
        .unwrap();
    std::fs::write(
        std::env::var("NATIVE_PUMAS_FACTS_OUTPUT").unwrap(),
        serde_json::to_vec_pretty(&facts).unwrap(),
    )
    .unwrap();
}
